/*******************************************************************************
 * Copyright 2022, the Glitchfiend Team.
 * All rights reserved.
 ******************************************************************************/
package biomesoplenty.worldgen.feature.misc;

import biomesoplenty.api.block.BOPBlocks;
import biomesoplenty.block.StringyCobwebBlock;
import biomesoplenty.block.properties.ConnectedProperty;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.SectionPos;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.chunk.ChunkGenerator;

public class StringyCobwebFeature implements Feature
{
    public static final int MIN_DISTANCE = 2;
    public static final int MAX_DISTANCE = 32;

    public static final MapCodec<StringyCobwebFeature> CODEC = MapCodec.unit(StringyCobwebFeature::new);

    @Override
    public MapCodec<StringyCobwebFeature> codec()
    {
        return CODEC;
    }


    public static boolean canPlace(WorldGenLevel world, BlockPos pos, int length, Direction dir)
    {
        if (!respectsCutoff((WorldGenRegion)world, pos))
            return false;

        BlockPos belowPos = pos.below();
        BlockState belowState = world.getBlockState(belowPos);

        if (!isStringyCobwebReplaceable(world.getBlockState(pos)) || !belowState.isFaceSturdy(world, belowPos, Direction.UP))
        {
            return false;
        }

        BlockPos nextStringPos = pos;

        for (int i = 0; i < length; i++)
        {
            nextStringPos = nextStringPos.relative(dir, 1).above(1);

            if (!respectsCutoff((WorldGenRegion)world, nextStringPos))
                return false;

            BlockState nextStringState = world.getBlockState(nextStringPos);

            if ((!nextStringState.isAir() && world.getBlockState(nextStringPos).getBlock() != Blocks.COBWEB && world.getBlockState(nextStringPos).getBlock() != Blocks.GLOW_LICHEN && world.getBlockState(nextStringPos).getBlock() != BOPBlocks.WEBBING))
            {
                return false;
            }
        }

        BlockPos abovePos = nextStringPos.above();
        BlockState aboveState = world.getBlockState(abovePos);

        if (!aboveState.isFaceSturdy(world, abovePos, Direction.DOWN))
        {
            return false;
        }

        return true;
    }

    public void placeCobweb(WorldGenLevel world, BlockPos pos, int length, Direction dir)
    {
        if (respectsCutoff((WorldGenRegion)world, pos))
        {
            world.setBlock(pos, BOPBlocks.STRINGY_COBWEB.defaultBlockState().setValue(StringyCobwebBlock.FACING, dir).setValue(StringyCobwebBlock.CONNECTED, ConnectedProperty.BOTTOM), 2);
        }

        BlockPos nextStringPos = pos;

        for (int i = 0; i < length; ++i)
        {
            nextStringPos = nextStringPos.relative(dir, 1).above(1);

            if (respectsCutoff((WorldGenRegion)world, nextStringPos))
            {
                world.setBlock(nextStringPos, BOPBlocks.STRINGY_COBWEB.defaultBlockState().setValue(StringyCobwebBlock.FACING, dir).setValue(StringyCobwebBlock.CONNECTED, ConnectedProperty.MIDDLE), 2);
            }
        }

        if (respectsCutoff((WorldGenRegion)world, nextStringPos))
        {
            world.setBlock(nextStringPos, BOPBlocks.STRINGY_COBWEB.defaultBlockState().setValue(StringyCobwebBlock.FACING, dir).setValue(StringyCobwebBlock.CONNECTED, ConnectedProperty.TOP), 2);
        }
    }

    @Override
    public boolean place(WorldGenLevel world, ChunkGenerator chunkGenerator, RandomSource rand, BlockPos pos)
    {
        int k = 0;

        for(int j = 0; j < 128; ++j)
        {
            int length = MIN_DISTANCE + rand.nextInt(MAX_DISTANCE - MIN_DISTANCE);
            Direction dir = Direction.Plane.HORIZONTAL.getRandomDirection(rand);
            BlockPos blockPos = pos.offset(rand.nextInt(8) - rand.nextInt(8), rand.nextInt(4) - rand.nextInt(4), rand.nextInt(8) - rand.nextInt(8));

            if (canPlace(world, blockPos, length, dir))
            {
                placeCobweb(world, blockPos, length, dir);
                ++k;
            }
        }

        return k > 0;
    }

    private static boolean respectsCutoff(WorldGenRegion region, BlockPos pos)
    {
        int i = SectionPos.blockToSectionCoord(pos.getX());
        int j = SectionPos.blockToSectionCoord(pos.getZ());
        ChunkPos chunkpos = region.getCenter();
        int k = Math.abs(chunkpos.x() - i);
        int l = Math.abs(chunkpos.z() - j);

        if (k <= region.generatingStep.blockStateWriteRadius() && l <= region.generatingStep.blockStateWriteRadius())
        {
            return true;
        }

        return false;
    }

    public static boolean isStringyCobwebReplaceable(BlockState state)
    {
        return state.isAir() || state.is(Blocks.COBWEB) || state.is(Blocks.GLOW_LICHEN) ||state.is(BOPBlocks.WEBBING);
    }
}
