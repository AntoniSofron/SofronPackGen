/*******************************************************************************
 * Copyright 2022, the Glitchfiend Team.
 * All rights reserved.
 ******************************************************************************/
package biomesoplenty.worldgen.feature.misc;

import biomesoplenty.api.block.BOPBlocks;
import biomesoplenty.block.BranchBlock;
import biomesoplenty.util.SimpleBlockPredicate;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.TreeFeature;
import net.minecraft.world.level.material.Fluids;
import com.mojang.serialization.MapCodec;

public class FallenDeadLogFeature implements Feature
{
    protected SimpleBlockPredicate placeOn = (world, pos) -> world.getBlockState(pos).getBlock() == Blocks.GRASS_BLOCK || world.getBlockState(pos).getBlock() == Blocks.COARSE_DIRT || world.getBlockState(pos).getBlock() == Blocks.PODZOL;
    protected SimpleBlockPredicate replace = (world, pos) -> TreeFeature.isAirOrLeaves(world, pos) || world.getBlockState(pos).getBlock() instanceof VegetationBlock || world.getBlockState(pos).getBlock() == Blocks.SNOW;

    public static final MapCodec<FallenDeadLogFeature> CODEC = MapCodec.unit(FallenDeadLogFeature::new);

    @Override
    public MapCodec<FallenDeadLogFeature> codec()
    {
        return CODEC;
    }


    @Override
    public boolean place(WorldGenLevel world, ChunkGenerator chunkGenerator, RandomSource rand, BlockPos startPos)
    {
        while (startPos.getY() >= world.getMinY()+1 && this.replace.matches(world, startPos)) {
            startPos = startPos.below();
        }

        int length = 4 + rand.nextInt(6);
        Direction direction = Direction.Plane.HORIZONTAL.getRandomDirection(rand);

        int groundCheck = 0;
        boolean startConnected = false;
        boolean endConnected = false;
        boolean generateStump = false;
        int stumpDistance = 2 + rand.nextInt(2);

        int groundRequired;
        if (length % 2 == 0)
        {
            groundRequired = length - 1;
        }
        else
        {
            groundRequired = length - 2;
        }

        for (int i = 0; i < length; i++)
        {
            if (this.placeOn.matches(world, startPos.relative(direction, i)))
            {
                if (i <= 1) { startConnected = true; }
                if (i >= length-2) { endConnected = true; }

                groundCheck++;
            }
        }

        if (groundCheck < groundRequired)
        {
            if (!startConnected)
            {
                return false;
            }
            if (!endConnected)
            {
                return false;
            }
        }

        if (!this.checkSpace(world, startPos.above(), direction, length))
        {
            // Abandon if there isn't enough room
            return false;
        }

        // Check if there's space for a stump
        if (this.placeOn.matches(world, startPos.relative(direction.getOpposite(), stumpDistance)))
        {
            if (this.checkSpace(world, startPos.above(), direction.getOpposite(), stumpDistance))
            {
                generateStump = true;
            }
        }

        BlockPos pos = startPos.above();

        //Stump
        if (generateStump)
        {
            BlockPos stumpPos = startPos.above().relative(direction.getOpposite(), stumpDistance);
            this.setBlock(world, stumpPos, BOPBlocks.DEAD_LOG.defaultBlockState());

            //Top
            if (rand.nextInt(2) == 0)
            {
                this.setBlock(world, stumpPos.above(), Blocks.PALE_MOSS_CARPET.defaultBlockState());
            }

            //Sides
            for (Direction face : Direction.Plane.HORIZONTAL)
            {
                if (rand.nextInt(2) == 0)
                {
                    this.setBlock(world, stumpPos.relative(face), BOPBlocks.DEAD_BRANCH.defaultBlockState().setValue(BranchBlock.FACING, face));
                }
            }

            //Roots
            BlockState blockBelow = world.getBlockState(stumpPos.below());
            if (blockBelow.is(BlockTags.SUPPORTS_VEGETATION))
            {
                Feature.super.setBlock(world, stumpPos.below(), Blocks.ROOTED_DIRT.defaultBlockState());
            }
        }

        //Fallen Log
        for (int i = 0; i < length; i++)
        {
            this.setBlock(world, pos.relative(direction, i), BOPBlocks.DEAD_LOG.defaultBlockState().setValue(RotatedPillarBlock.AXIS, direction.getAxis()));

            //Top
            BlockState blockAbove = world.getBlockState(pos.above().relative(direction, i));
            if (blockAbove.isAir() || blockAbove.getBlock() instanceof VegetationBlock || blockAbove.getBlock() == Blocks.SNOW)
            {
                if (rand.nextInt(4) == 0)
                {
                    this.setBlock(world, pos.above().relative(direction, i), Blocks.PALE_MOSS_CARPET.defaultBlockState());
                }
                else
                {
                    this.setBlock(world, pos.above().relative(direction, i), Blocks.LEAF_LITTER.defaultBlockState().setValue(LeafLitterBlock.AMOUNT,1+rand.nextInt(4)).setValue(LeafLitterBlock.FACING, Direction.Plane.HORIZONTAL.getRandomDirection(rand)));
                }
            }

            //Sides
            BlockState blockClockwise = world.getBlockState(pos.relative(direction, i).relative(direction.getClockWise()));
            if (blockClockwise.isAir() || blockClockwise.getBlock() instanceof VegetationBlock || blockClockwise.getBlock() == Blocks.SNOW)
            {
                if (rand.nextInt(4) == 0)
                {
                    this.setBlock(world, pos.relative(direction, i).relative(direction.getClockWise()), BOPBlocks.DEAD_BRANCH.defaultBlockState().setValue(BranchBlock.FACING, direction.getClockWise()));
                }
            }

            BlockState blockCounterClockwise = world.getBlockState(pos.relative(direction, i).relative(direction.getCounterClockWise()));
            if (blockCounterClockwise.isAir() || blockCounterClockwise.getBlock() instanceof VegetationBlock || blockCounterClockwise.getBlock() == Blocks.SNOW)
            {
                if (rand.nextInt(4) == 0)
                {
                    this.setBlock(world, pos.relative(direction, i).relative(direction.getCounterClockWise()), BOPBlocks.DEAD_BRANCH.defaultBlockState().setValue(BranchBlock.FACING, direction.getCounterClockWise()));
                }
            }

            //Roots
            BlockState blockBelow = world.getBlockState(pos.below().relative(direction, i));
            if (blockBelow.isAir() || blockBelow.getFluidState().is(Fluids.WATER) || blockBelow.getBlock() instanceof VegetationBlock || blockBelow.getBlock() == Blocks.SNOW)
            {
                this.setBlock(world, pos.below().relative(direction, i), Blocks.HANGING_ROOTS.defaultBlockState().setValue(BlockStateProperties.WATERLOGGED, Boolean.valueOf(world.isWaterAt(pos.below().relative(direction, i)))));
            }
            if (blockBelow.is(BlockTags.SUPPORTS_VEGETATION))
            {
                Feature.super.setBlock(world, pos.below().relative(direction, i), Blocks.ROOTED_DIRT.defaultBlockState());
            }
        }

        return true;
    }

    public boolean setBlock(WorldGenLevel world, BlockPos pos, BlockState state)
    {
        if (this.replace.matches(world, pos))
        {
            Feature.super.setBlock(world, pos, state);
            return true;
        }
        else if (world.getBlockState(pos).getFluidState().is(Fluids.WATER) && state.getBlock() == Blocks.HANGING_ROOTS)
        {
            Feature.super.setBlock(world, pos, state);
            return true;
        }

        return false;
    }

    public boolean checkSpace(WorldGenLevel world, BlockPos pos, Direction direction, int length)
    {
        for (int y = 0; y <= 2; y++)
        {
            for (int i = 0; i < length; i++)
            {
                BlockPos pos1 = pos.above(y).relative(direction, i);
                if (pos1.getY() >= 255 || !this.replace.matches(world, pos1))
                {
                    return false;
                }
            }
        }
        return true;
    }
}
