/*******************************************************************************
 * Copyright 2022, the Glitchfiend Team.
 * All rights reserved.
 ******************************************************************************/
package biomesoplenty.worldgen.feature.misc;

import biomesoplenty.api.block.BOPBlocks;
import biomesoplenty.util.biome.RoseQuartzUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.util.valueproviders.FloatProvider;
import net.minecraft.util.valueproviders.FloatProviders;
import net.minecraft.util.valueproviders.IntProvider;
import net.minecraft.util.valueproviders.IntProviders;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.AmethystClusterBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.Column;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.Optional;

public class LargeRoseQuartzFeature implements Feature
{
    public static final MapCodec<LargeRoseQuartzFeature> CODEC = RecordCodecBuilder.mapCodec(
        i -> i.group(
                Codec.intRange(1, 512).optionalFieldOf("floor_to_ceiling_search_range", 30).forGetter(f -> f.floorToCeilingSearchRange),
                IntProviders.codec(1, 16).fieldOf("column_radius").forGetter(f -> f.columnRadius),
                FloatProviders.codec(0.0F, 20.0F).fieldOf("height_scale").forGetter(f -> f.heightScale),
                Codec.floatRange(0.1F, 1.0F).fieldOf("max_column_radius_to_cave_height_ratio").forGetter(f -> f.maxColumnRadiusToCaveHeightRatio),
                FloatProviders.codec(0.1F, 10.0F).fieldOf("stalactite_bluntness").forGetter(f -> f.stalactiteBluntness),
                FloatProviders.codec(0.1F, 10.0F).fieldOf("stalagmite_bluntness").forGetter(f -> f.stalagmiteBluntness),
                FloatProviders.codec(0.0F, 2.0F).fieldOf("wind_speed").forGetter(f -> f.windSpeed),
                Codec.intRange(0, 100).fieldOf("min_radius_for_wind").forGetter(f -> f.minRadiusForWind),
                Codec.floatRange(0.0F, 5.0F).fieldOf("min_bluntness_for_wind").forGetter(f -> f.minBluntnessForWind)
            ).apply(i, LargeRoseQuartzFeature::new)
    );

    @Override
    public MapCodec<LargeRoseQuartzFeature> codec()
    {
        return CODEC;
    }

    public final int floorToCeilingSearchRange;
    public final IntProvider columnRadius;
    public final FloatProvider heightScale;
    public final float maxColumnRadiusToCaveHeightRatio;
    public final FloatProvider stalactiteBluntness;
    public final FloatProvider stalagmiteBluntness;
    public final FloatProvider windSpeed;
    public final int minRadiusForWind;
    public final float minBluntnessForWind;

    public LargeRoseQuartzFeature(int floorToCeilingSearchRange, IntProvider columnRadius, FloatProvider heightScale, float maxColumnRadiusToCaveHeightRatio, FloatProvider stalactiteBluntness, FloatProvider stalagmiteBluntness, FloatProvider windSpeed, int minRadiusForWind, float minBluntnessForWind)
    {
        this.floorToCeilingSearchRange = floorToCeilingSearchRange;
        this.columnRadius = columnRadius;
        this.heightScale = heightScale;
        this.maxColumnRadiusToCaveHeightRatio = maxColumnRadiusToCaveHeightRatio;
        this.stalactiteBluntness = stalactiteBluntness;
        this.stalagmiteBluntness = stalagmiteBluntness;
        this.windSpeed = windSpeed;
        this.minRadiusForWind = minRadiusForWind;
        this.minBluntnessForWind = minBluntnessForWind;
    }


    @Override
    public boolean place(WorldGenLevel worldgenlevel, ChunkGenerator chunkGenerator, RandomSource random, BlockPos blockpos)
    {
        if (!RoseQuartzUtils.isEmptyOrWater(worldgenlevel, blockpos))
        {
            return false;
        }
        else
        {
            Optional<Column> optional = Column.scan(worldgenlevel, blockpos, this.floorToCeilingSearchRange, RoseQuartzUtils::isEmptyOrWater, RoseQuartzUtils::isRoseQuartzBaseOrLava);
            if (optional.isPresent() && optional.get() instanceof Column.Range)
            {
                Column.Range column$range = (Column.Range)optional.get();
                if (column$range.height() < 4)
                {
                    return false;
                }
                else
                {
                    int i = (int)((float)column$range.height() * this.maxColumnRadiusToCaveHeightRatio);
                    int j = Mth.clamp(i, this.columnRadius.minInclusive(), this.columnRadius.maxInclusive());
                    int k = Mth.randomBetweenInclusive(random, this.columnRadius.minInclusive(), j);
                    LargeRoseQuartzFeature.LargeRoseQuartz largedripstonefeature$largedripstone = makeRoseQuartz(blockpos.atY(column$range.ceiling() - 1), false, random, k, this.stalactiteBluntness, this.heightScale);
                    LargeRoseQuartzFeature.LargeRoseQuartz largedripstonefeature$largedripstone1 = makeRoseQuartz(blockpos.atY(column$range.floor() + 1), true, random, k, this.stalagmiteBluntness, this.heightScale);
                    LargeRoseQuartzFeature.WindOffsetter largedripstonefeature$windoffsetter;
                    if (largedripstonefeature$largedripstone.isSuitableForWind(this) && largedripstonefeature$largedripstone1.isSuitableForWind(this)) {
                        largedripstonefeature$windoffsetter = new LargeRoseQuartzFeature.WindOffsetter(blockpos.getY(), random, this.windSpeed);
                    }
                    else
                    {
                        largedripstonefeature$windoffsetter = LargeRoseQuartzFeature.WindOffsetter.noWind();
                    }

                    boolean flag = largedripstonefeature$largedripstone.moveBackUntilBaseIsInsideStoneAndShrinkRadiusIfNecessary(worldgenlevel, largedripstonefeature$windoffsetter);
                    boolean flag1 = largedripstonefeature$largedripstone1.moveBackUntilBaseIsInsideStoneAndShrinkRadiusIfNecessary(worldgenlevel, largedripstonefeature$windoffsetter);
                    if (flag)
                    {
                        largedripstonefeature$largedripstone.placeBlocks(worldgenlevel, random, largedripstonefeature$windoffsetter);
                    }

                    if (flag1)
                    {
                        largedripstonefeature$largedripstone1.placeBlocks(worldgenlevel, random, largedripstonefeature$windoffsetter);
                    }

                    return true;
                }
            }
            else
            {
                return false;
            }
        }
    }

    private static LargeRoseQuartzFeature.LargeRoseQuartz makeRoseQuartz(BlockPos p_159969_, boolean p_159970_, RandomSource p_159971_, int p_159972_, FloatProvider p_159973_, FloatProvider p_159974_)
    {
        return new LargeRoseQuartzFeature.LargeRoseQuartz(p_159969_, p_159970_, p_159972_, (double)p_159973_.sample(p_159971_), (double)p_159974_.sample(p_159971_));
    }

    static final class LargeRoseQuartz
    {
        private BlockPos root;
        private final boolean pointingUp;
        private int radius;
        private final double bluntness;
        private final double scale;

        LargeRoseQuartz(BlockPos p_159981_, boolean p_159982_, int p_159983_, double p_159984_, double p_159985_)
        {
            this.root = p_159981_;
            this.pointingUp = p_159982_;
            this.radius = p_159983_;
            this.bluntness = p_159984_;
            this.scale = p_159985_;
        }

        private int getHeight() {
            return this.getHeightAtRadius(0.0F);
        }

        private int getMinY() {
            return this.pointingUp ? this.root.getY() : this.root.getY() - this.getHeight();
        }

        private int getMaxY() {
            return !this.pointingUp ? this.root.getY() : this.root.getY() + this.getHeight();
        }

        boolean moveBackUntilBaseIsInsideStoneAndShrinkRadiusIfNecessary(WorldGenLevel p_159990_, LargeRoseQuartzFeature.WindOffsetter p_159991_)
        {
            while(this.radius > 1)
            {
                BlockPos.MutableBlockPos blockpos$mutableblockpos = this.root.mutable();
                int i = Math.min(10, this.getHeight());

                for(int j = 0; j < i; ++j)
                {
                    if (p_159990_.getBlockState(blockpos$mutableblockpos).is(Blocks.LAVA))
                    {
                        return false;
                    }

                    if (RoseQuartzUtils.isCircleMostlyEmbeddedInStone(p_159990_, p_159991_.offset(blockpos$mutableblockpos), this.radius))
                    {
                        this.root = blockpos$mutableblockpos;
                        return true;
                    }

                    blockpos$mutableblockpos.move(this.pointingUp ? Direction.DOWN : Direction.UP);
                }

                this.radius /= 2;
            }

            return false;
        }

        private int getHeightAtRadius(float p_159988_)
        {
            return (int) RoseQuartzUtils.getRoseQuartzHeight((double)p_159988_, (double)this.radius, this.scale, this.bluntness);
        }

        void placeBlocks(WorldGenLevel p_159993_, RandomSource p_159994_, LargeRoseQuartzFeature.WindOffsetter p_159995_)
        {
            for(int i = -this.radius; i <= this.radius; ++i)
            {
                for(int j = -this.radius; j <= this.radius; ++j)
                {
                    float f = Mth.sqrt((float)(i * i + j * j));
                    if (!(f > (float)this.radius))
                    {
                        int k = this.getHeightAtRadius(f);
                        if (k > 0)
                        {
                            if ((double)p_159994_.nextFloat() < 0.2D)
                            {
                                k = (int)((float)k * Mth.randomBetween(p_159994_, 0.8F, 1.0F));
                            }

                            BlockPos.MutableBlockPos blockpos$mutableblockpos = this.root.offset(i, 0, j).mutable();
                            boolean flag = false;

                            for(int l = 0; l < k; ++l)
                            {
                                BlockPos blockpos = p_159995_.offset(blockpos$mutableblockpos);
                                if (RoseQuartzUtils.isEmptyOrWaterOrLava(p_159993_, blockpos) || p_159993_.getBlockState(blockpos).is(BlockTags.CRYSTAL_SOUND_BLOCKS) || p_159993_.getBlockState(blockpos).getBlock() instanceof AmethystClusterBlock)
                                {
                                    flag = true;
                                    Block block = BOPBlocks.ROSE_QUARTZ_BLOCK;
                                    p_159993_.setBlock(blockpos, block.defaultBlockState(), 2);

                                    for (Direction direction : Direction.values())
                                    {
                                        if (p_159994_.nextInt(2) == 0)
                                        {
                                            BlockState cluster_state;
                                            switch (p_159994_.nextInt(6))
                                            {
                                                case 3:
                                                    cluster_state = BOPBlocks.ROSE_QUARTZ_CLUSTER.defaultBlockState();
                                                    break;

                                                case 2:
                                                default:
                                                    cluster_state = BOPBlocks.LARGE_ROSE_QUARTZ_BUD.defaultBlockState();
                                                    break;

                                                case 1:
                                                    cluster_state = BOPBlocks.MEDIUM_ROSE_QUARTZ_BUD.defaultBlockState();
                                                    break;

                                                case 0:
                                                    cluster_state = BOPBlocks.SMALL_ROSE_QUARTZ_BUD.defaultBlockState();
                                                    break;
                                            }

                                            BlockState state = cluster_state.setValue(AmethystClusterBlock.FACING, direction);
                                            if (p_159993_.isEmptyBlock(blockpos.relative(direction)) && state.canSurvive(p_159993_, blockpos.relative(direction)))
                                            {
                                                p_159993_.setBlock(blockpos.relative(direction), state, 2);
                                            }
                                        }
                                    }
                                }
                                else if (flag && p_159993_.getBlockState(blockpos).is(Blocks.NETHERRACK))
                                {
                                    break;
                                }

                                blockpos$mutableblockpos.move(this.pointingUp ? Direction.UP : Direction.DOWN);
                            }
                        }
                    }
                }
            }

        }

        boolean isSuitableForWind(LargeRoseQuartzFeature p_159997_) {
            return this.radius >= p_159997_.minRadiusForWind && this.bluntness >= (double)p_159997_.minBluntnessForWind;
        }
    }

    static final class WindOffsetter {
        private final int originY;
        @Nullable
        private final Vec3 windSpeed;

        WindOffsetter(int p_160004_, RandomSource p_160005_, FloatProvider p_160006_) {
            this.originY = p_160004_;
            float f = p_160006_.sample(p_160005_);
            float f1 = Mth.randomBetween(p_160005_, 0.0F, (float)Math.PI);
            this.windSpeed = new Vec3((double)(Mth.cos(f1) * f), 0.0D, (double)(Mth.sin(f1) * f));
        }

        private WindOffsetter() {
            this.originY = 0;
            this.windSpeed = null;
        }

        static LargeRoseQuartzFeature.WindOffsetter noWind() {
            return new LargeRoseQuartzFeature.WindOffsetter();
        }

        BlockPos offset(BlockPos p_160009_) {
            if (this.windSpeed == null) {
                return p_160009_;
            } else {
                int i = this.originY - p_160009_.getY();
                Vec3 vec3 = this.windSpeed.scale((double)i);
                return p_160009_.offset(Mth.floor(vec3.x), 0, Mth.floor(vec3.z));
            }
        }
    }
}
