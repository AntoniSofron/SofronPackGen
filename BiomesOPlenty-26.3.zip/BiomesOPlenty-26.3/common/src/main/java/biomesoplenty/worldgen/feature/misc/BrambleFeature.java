/*******************************************************************************
 * Copyright 2022, the Glitchfiend Team.
 * All rights reserved.
 ******************************************************************************/
package biomesoplenty.worldgen.feature.misc;

import biomesoplenty.api.block.BOPBlocks;
import biomesoplenty.block.BrambleBlock;
import biomesoplenty.util.SimpleBlockPredicate;
import biomesoplenty.util.biome.GeneratorUtil;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DirectionalBlock;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.feature.Feature;
import com.mojang.serialization.MapCodec;

public class BrambleFeature implements Feature
{
    public static final MapCodec<BrambleFeature> CODEC = MapCodec.unit(BrambleFeature::new);

    @Override
    public MapCodec<BrambleFeature> codec()
    {
        return CODEC;
    }


    protected SimpleBlockPredicate placeOn = (world, pos) ->
    {
        BlockState state = world.getBlockState(pos);
        return Blocks.OAK_SAPLING.defaultBlockState().canSurvive(world, pos.above()) || state.getBlock() == Blocks.NETHERRACK;
    };

    protected SimpleBlockPredicate replace = (world, pos) -> world.getBlockState(pos).isAir();

    @Override
    public boolean place(WorldGenLevel world, ChunkGenerator chunkGenerator, RandomSource rand, BlockPos startPos)
    {
        for (int i = 0; i < 128; ++i)
        {
            BlockPos genPos = startPos.offset(rand.nextInt(4) - rand.nextInt(4), rand.nextInt(3) - rand.nextInt(3), rand.nextInt(4) - rand.nextInt(4));

            if (this.placeOn.matches(world, genPos.below()) && this.replace.matches(world, genPos))
            {
                int targetLength = GeneratorUtil.nextIntBetween(rand, 15, 30);
                int height = 0;
                int direction = rand.nextInt(4) + 2;

                for (int length = 0; length <= targetLength && replace.matches(world, genPos); length++)
                {
                    //if (BrambleBlock.canPlaceBlockAt(world, genPos))
                    //{
                    world.setBlock(genPos, ((BrambleBlock) BOPBlocks.BRAMBLE).makeConnections(world, genPos), 2);

                    for (Direction face : Direction.values())
                    {
                        if (world.getBlockState(genPos.relative(face)).getBlock() == BOPBlocks.BRAMBLE)
                        {
                            world.setBlock(genPos.relative(face), ((BrambleBlock)BOPBlocks.BRAMBLE).makeConnections(world, genPos.relative(face)), 2);
                        }
                    }

                    if (rand.nextInt(2) == 0)
                    {
                        direction = rand.nextInt(4) + 2;
                    }

                    if (rand.nextInt(2) == 0)
                    {
                        int leafDirection = rand.nextInt(6);
                        BlockPos leafPos = genPos.relative(Direction.values()[leafDirection]);
                        if (world.isEmptyBlock(leafPos))
                        {
                            world.setBlock(leafPos, BOPBlocks.BRAMBLE_LEAVES.defaultBlockState().setValue(DirectionalBlock.FACING, Direction.values()[leafDirection]), 19);
                            for (Direction face : Direction.values())
                            {
                                if (world.getBlockState(leafPos.relative(face)).getBlock() == BOPBlocks.BRAMBLE)
                                {
                                    world.setBlock(leafPos.relative(face), ((BrambleBlock)BOPBlocks.BRAMBLE).makeConnections(world, leafPos.relative(face)), 2);
                                }
                            }
                        }
                    }

                    switch (rand.nextInt(6))
                    {
                        case 0: case 1:
                        if (height <= 8)
                        {
                            genPos = genPos.above();
                            height++;
                        }
                        break;
                        case 2:
                            if (height >= 0)
                            {
                                genPos = genPos.below();
                                height--;
                            }
                            break;
                        default:
                            genPos = genPos.relative(Direction.values()[direction]);
                            break;
                    }
                }
            }
        }
        return true;
    }
}
