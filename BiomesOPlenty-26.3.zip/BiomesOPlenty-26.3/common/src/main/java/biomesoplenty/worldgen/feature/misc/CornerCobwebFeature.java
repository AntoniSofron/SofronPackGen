/*******************************************************************************
 * Copyright 2022, the Glitchfiend Team.
 * All rights reserved.
 ******************************************************************************/
package biomesoplenty.worldgen.feature.misc;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.TreeFeature;
import com.mojang.serialization.MapCodec;

public class CornerCobwebFeature implements Feature
{
    public static final MapCodec<CornerCobwebFeature> CODEC = MapCodec.unit(CornerCobwebFeature::new);

    @Override
    public MapCodec<CornerCobwebFeature> codec()
    {
        return CODEC;
    }


    @Override
    public boolean place(WorldGenLevel world, ChunkGenerator chunkGenerator, RandomSource rand, BlockPos pos)
    {
        int i = 0;

        for(int j = 0; j < 64; ++j)
        {
            BlockPos blockpos = pos.offset(rand.nextInt(8) - rand.nextInt(8), rand.nextInt(4) - rand.nextInt(4), rand.nextInt(8) - rand.nextInt(8));
            if (TreeFeature.isAirOrLeaves(world, blockpos))
            {
                int k = 0;

                for (Direction direction : Direction.values())
                {
                    if (world.getBlockState(blockpos.relative(direction)).is(BlockTags.DRIPSTONE_REPLACEABLE))
                    {
                        k++;
                    }
                }

                if (k > 2)
                {
                    world.setBlock(blockpos, Blocks.COBWEB.defaultBlockState(), 2);
                }

                ++i;
            }
        }

        return i > 0;
    }
}
