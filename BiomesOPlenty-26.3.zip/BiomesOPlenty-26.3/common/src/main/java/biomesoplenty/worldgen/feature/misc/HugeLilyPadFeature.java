/*******************************************************************************
 * Copyright 2022, the Glitchfiend Team.
 * All rights reserved.
 ******************************************************************************/
package biomesoplenty.worldgen.feature.misc;

import biomesoplenty.api.block.BOPBlocks;
import biomesoplenty.block.HugeLilyPadBlock;
import biomesoplenty.block.properties.QuarterProperty;
import biomesoplenty.util.SimpleBlockPredicate;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.IceBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.TreeFeature;
import net.minecraft.world.level.material.Fluids;
import com.mojang.serialization.MapCodec;

public class HugeLilyPadFeature implements Feature
{
    protected SimpleBlockPredicate placeOn = (world, pos) -> (world.getBlockState(pos).getFluidState().getType() == Fluids.WATER || world.getBlockState(pos).getBlock() instanceof IceBlock) && world.getBlockState(pos.above()).getFluidState().getType() == Fluids.EMPTY;
    protected SimpleBlockPredicate replace = (world, pos) -> TreeFeature.isAirOrLeaves(world, pos) || world.getBlockState(pos).getBlock() == BOPBlocks.WATERGRASS;

    public static final MapCodec<HugeLilyPadFeature> CODEC = MapCodec.unit(HugeLilyPadFeature::new);

    @Override
    public MapCodec<HugeLilyPadFeature> codec()
    {
        return CODEC;
    }


    @Override
    public boolean place(WorldGenLevel world, ChunkGenerator chunkGenerator, RandomSource rand, BlockPos startPos)
    {
        Direction direction = Direction.Plane.HORIZONTAL.getRandomDirection(rand);
        while (startPos.getY() >= world.getMinY()+1 && this.replace.matches(world, startPos)) {startPos = startPos.below();}

        if (!this.placeOn.matches(world, startPos))
        {
            // Abandon if we can't place the tree on this block
            return false;
        }

        if (!this.checkSpace(world, startPos.above(), direction))
        {
            // Abandon if there isn't enough room
            return false;
        }

        BlockPos pos = startPos.above();

        this.setBlock(world, pos, BOPBlocks.HUGE_LILY_PAD.defaultBlockState().setValue(HugeLilyPadBlock.QUARTER, QuarterProperty.SOUTH_WEST).setValue(HorizontalDirectionalBlock.FACING, direction));
        this.setBlock(world, pos.relative(direction), BOPBlocks.HUGE_LILY_PAD.defaultBlockState().setValue(HugeLilyPadBlock.QUARTER, QuarterProperty.NORTH_WEST).setValue(HorizontalDirectionalBlock.FACING, direction));
        this.setBlock(world, pos.relative(direction).relative(direction.getClockWise()), BOPBlocks.HUGE_LILY_PAD.defaultBlockState().setValue(HugeLilyPadBlock.QUARTER, QuarterProperty.NORTH_EAST).setValue(HorizontalDirectionalBlock.FACING, direction));
        this.setBlock(world, pos.relative(direction.getClockWise()), BOPBlocks.HUGE_LILY_PAD.defaultBlockState().setValue(HugeLilyPadBlock.QUARTER, QuarterProperty.SOUTH_EAST).setValue(HorizontalDirectionalBlock.FACING, direction));

        return true;
    }

    public boolean setBlock(WorldGenLevel world, BlockPos pos, BlockState state)
    {
        if (this.replace.matches(world, pos))
        {
            Feature.super.setBlock(world, pos, state);
            Feature.super.markAboveForPostProcessing(world, pos.below());
            return true;
        }
        return false;
    }

    public boolean checkSpace(WorldGenLevel world, BlockPos pos, Direction direction)
    {
        BlockPos pos1 = pos;
        BlockPos pos2 = pos.relative(direction);
        BlockPos pos3 = pos2.relative(direction.getClockWise());
        BlockPos pos4 = pos.relative(direction.getClockWise());
        if (pos1.getY() >= 255 || !this.replace.matches(world, pos1) || !this.placeOn.matches(world, pos1.below()) ||
            pos2.getY() >= 255 || !this.replace.matches(world, pos2) || !this.placeOn.matches(world, pos2.below()) ||
            pos3.getY() >= 255 || !this.replace.matches(world, pos3) || !this.placeOn.matches(world, pos3.below()) ||
            pos4.getY() >= 255 || !this.replace.matches(world, pos4) || !this.placeOn.matches(world, pos4.below()))
        {
            return false;
        }

        return true;
    }
}
