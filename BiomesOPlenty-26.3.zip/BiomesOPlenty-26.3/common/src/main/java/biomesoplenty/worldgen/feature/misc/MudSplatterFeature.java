/*******************************************************************************
 * Copyright 2022, the Glitchfiend Team.
 * All rights reserved.
 ******************************************************************************/
package biomesoplenty.worldgen.feature.misc;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelSimulatedReader;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeafLitterBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.feature.Feature;
import com.mojang.serialization.MapCodec;

public class MudSplatterFeature implements Feature
{
    public static final MapCodec<MudSplatterFeature> CODEC = MapCodec.unit(MudSplatterFeature::new);

    @Override
    public MapCodec<MudSplatterFeature> codec()
    {
        return CODEC;
    }


    @Override
    public boolean place(WorldGenLevel worldIn, ChunkGenerator chunkGenerator, RandomSource rand, BlockPos pos)
    {
        int i = 0;
        int j = rand.nextInt(8 - 2) + 2;

        for (int k = pos.getX() - j; k <= pos.getX() + j; ++k)
        {
            for (int l = pos.getZ() - j; l <= pos.getZ() + j; ++l)
            {
                int i1 = k - pos.getX();
                int j1 = l - pos.getZ();
                if (i1 * i1 + j1 * j1 <= j * j)
                {
                    for (int k1 = pos.getY() - 2; k1 <= pos.getY() + 2; ++k1)
                    {
                        BlockPos blockpos = new BlockPos(k, k1, l);
                        BlockState blockstate = worldIn.getBlockState(blockpos);
                        BlockState blockstate1 = worldIn.getBlockState(blockpos.above());

                        if (blockstate.getBlock() == Blocks.GRASS_BLOCK && blockstate1.is(BlockTags.REPLACEABLE))
                        {
                            if (rand.nextInt(6) == 0)
                            {
                                worldIn.setBlock(blockpos, Blocks.PODZOL.defaultBlockState(), 2);

                                if (rand.nextInt(6) == 0)
                                {
                                    worldIn.setBlock(blockpos.above(), Blocks.BROWN_MUSHROOM.defaultBlockState(), 2);
                                }
                                else if (rand.nextInt(4) == 0)
                                {
                                    worldIn.setBlock(blockpos.above(), Blocks.LEAF_LITTER.defaultBlockState().setValue(LeafLitterBlock.AMOUNT,1+rand.nextInt(4)).setValue(LeafLitterBlock.FACING, Direction.Plane.HORIZONTAL.getRandomDirection(rand)), 2);
                                }
                            }
                            else
                            {
                                worldIn.setBlock(blockpos, Blocks.MUD.defaultBlockState(), 2);

                                if (rand.nextInt(15) == 0)
                                {
                                    worldIn.setBlock(blockpos.above(), Blocks.DEAD_BUSH.defaultBlockState(), 2);
                                }
                                else if (rand.nextInt(3) == 0)
                                {
                                    worldIn.setBlock(blockpos.above(), Blocks.LEAF_LITTER.defaultBlockState().setValue(LeafLitterBlock.AMOUNT,1+rand.nextInt(4)).setValue(LeafLitterBlock.FACING, Direction.Plane.HORIZONTAL.getRandomDirection(rand)), 2);
                                }
                            }

                            ++i;
                            break;
                        }
                    }
                }
            }
        }

        return i > 0;
    }

    public static boolean isAir(LevelSimulatedReader level, BlockPos pos)
    {
        return level.isStateAtPosition(pos, BlockBehaviour.BlockStateBase::isAir);
    }
}
