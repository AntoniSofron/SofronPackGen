/*******************************************************************************
 * Copyright 2022, the Glitchfiend Team.
 * All rights reserved.
 ******************************************************************************/
package biomesoplenty.worldgen.feature;

import net.minecraft.data.worldgen.BlockStateProviders;
import biomesoplenty.worldgen.feature.misc.*;
import biomesoplenty.worldgen.feature.tree.*;
import biomesoplenty.api.block.BOPBlocks;
import biomesoplenty.worldgen.placement.BOPTreePlacements;
import biomesoplenty.util.worldgen.BOPFeatureUtils;
import com.google.common.collect.ImmutableList;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.data.worldgen.features.FeatureUtils;
import net.minecraft.data.worldgen.placement.PlacementUtils;
import net.minecraft.data.worldgen.placement.TreePlacements;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.random.WeightedList;
import net.minecraft.util.random.WeightedList;
import net.minecraft.util.valueproviders.ConstantInt;
import net.minecraft.util.valueproviders.IntProvider;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.util.valueproviders.WeightedListInt;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FlowerBedBlock;
import net.minecraft.world.level.block.LeafLitterBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.world.level.levelgen.feature.WeightedPlacedFeature;
import net.minecraft.world.level.levelgen.feature.featuresize.TwoLayersFeatureSize;
import net.minecraft.world.level.levelgen.feature.foliageplacers.CherryFoliagePlacer;
import net.minecraft.world.level.levelgen.feature.stateproviders.BlockStateProvider;
import net.minecraft.world.level.levelgen.feature.stateproviders.WeightedStateProvider;
import net.minecraft.world.level.levelgen.feature.trunkplacers.CherryTrunkPlacer;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;

import java.util.List;

public class BOPVegetationFeatures
{
    public static final ResourceKey<Feature> HIGH_GRASS = BOPFeatureUtils.createKey("high_grass");
    public static final ResourceKey<Feature> BIG_DRIPLEAF = BOPFeatureUtils.createKey("big_dripleaf");
    public static final ResourceKey<Feature> BIG_PUMPKIN = BOPFeatureUtils.createKey("big_pumpkin");
    public static final ResourceKey<Feature> BRAMBLE = BOPFeatureUtils.createKey("bramble");
    public static final ResourceKey<Feature> COLD_DESERT_ROCKS = BOPFeatureUtils.createKey("cold_desert_rocks");
    public static final ResourceKey<Feature> FALLEN_LOG = BOPFeatureUtils.createKey("fallen_log");
    public static final ResourceKey<Feature> FALLEN_FIR_LOG = BOPFeatureUtils.createKey("fallen_fir_log");
    public static final ResourceKey<Feature> FALLEN_BIRCH_LOG = BOPFeatureUtils.createKey("fallen_birch_log");
    public static final ResourceKey<Feature> FALLEN_DEAD_LOG = BOPFeatureUtils.createKey("fallen_dead_log");
    public static final ResourceKey<Feature> FALLEN_JACARANDA_LOG = BOPFeatureUtils.createKey("fallen_jacaranda_log");
    public static final ResourceKey<Feature> GOLDENROD = BOPFeatureUtils.createKey("goldenrod");
    public static final ResourceKey<Feature> HOT_SPRING_VENTS = BOPFeatureUtils.createKey("hot_spring_vents");
    public static final ResourceKey<Feature> HUGE_CLOVER = BOPFeatureUtils.createKey("huge_clover");
    public static final ResourceKey<Feature> HUGE_FLOWER = BOPFeatureUtils.createKey("huge_flower");
    public static final ResourceKey<Feature> HUGE_LILY_PAD = BOPFeatureUtils.createKey("huge_lily_pad");
    public static final ResourceKey<Feature> HUGE_TOADSTOOL = BOPFeatureUtils.createKey("huge_toadstool");
    public static final ResourceKey<Feature> DRIPSTONE_SPLATTER = BOPFeatureUtils.createKey("dripstone_splatter");
    public static final ResourceKey<Feature> MOSS_SPLATTER = BOPFeatureUtils.createKey("moss_splatter");
    public static final ResourceKey<Feature> MYCELIUM_SPLATTER = BOPFeatureUtils.createKey("mycelium_splatter");
    public static final ResourceKey<Feature> PATCH_BARLEY = BOPFeatureUtils.createKey("patch_barley");
    public static final ResourceKey<Feature> PATCH_BLUE_HYDRANGEA = BOPFeatureUtils.createKey("patch_blue_hydrangea");
    public static final ResourceKey<Feature> PATCH_BUSH = BOPFeatureUtils.createKey("patch_bush");
    public static final ResourceKey<Feature> PATCH_CATTAIL = BOPFeatureUtils.createKey("patch_cattail");
    public static final ResourceKey<Feature> PATCH_CLOVER = BOPFeatureUtils.createKey("patch_clover");
    public static final ResourceKey<Feature> PATCH_DEAD_GRASS = BOPFeatureUtils.createKey("patch_dead_grass");
    public static final ResourceKey<Feature> PATCH_DESERT_GRASS = BOPFeatureUtils.createKey("patch_desert_grass");
    public static final ResourceKey<Feature> PATCH_DRY_GRASS = BOPFeatureUtils.createKey("patch_dry_grass");
    public static final ResourceKey<Feature> PATCH_DUNE_GRASS = BOPFeatureUtils.createKey("patch_dune_grass");
    public static final ResourceKey<Feature> PATCH_FERN = BOPFeatureUtils.createKey("patch_fern");
    public static final ResourceKey<Feature> PATCH_FLOWER_BUDS = BOPFeatureUtils.createKey("patch_flower_buds");
    public static final ResourceKey<Feature> PATCH_ICY_IRIS = BOPFeatureUtils.createKey("patch_icy_iris");
    public static final ResourceKey<Feature> PATCH_PITCHER_PLANT = BOPFeatureUtils.createKey("patch_pitcher_plant");
    public static final ResourceKey<Feature> PATCH_LILAC = BOPFeatureUtils.createKey("patch_lilac");
    public static final ResourceKey<Feature> PATCH_PEONY = BOPFeatureUtils.createKey("patch_peony");
    public static final ResourceKey<Feature> PATCH_REED = BOPFeatureUtils.createKey("patch_reed");
    public static final ResourceKey<Feature> PATCH_SEA_OATS = BOPFeatureUtils.createKey("patch_sea_oats");
    public static final ResourceKey<Feature> PATCH_SPROUTS = BOPFeatureUtils.createKey("patch_sprouts");
    public static final ResourceKey<Feature> PATCH_TALL_LAVENDER = BOPFeatureUtils.createKey("patch_tall_lavender");
    public static final ResourceKey<Feature> PATCH_TALL_WHITE_LAVENDER = BOPFeatureUtils.createKey("patch_tall_white_lavender");
    public static final ResourceKey<Feature> PATCH_TINY_CACTUS = BOPFeatureUtils.createKey("patch_tiny_cactus");
    public static final ResourceKey<Feature> PATCH_TUNDRA_SHRUBS = BOPFeatureUtils.createKey("patch_tundra_shrubs");
    public static final ResourceKey<Feature> PATCH_WATERGRASS = BOPFeatureUtils.createKey("patch_watergrass");
    public static final ResourceKey<Feature> PATCH_WATERLILY_FLOWER = BOPFeatureUtils.createKey("patch_waterlily_flower");
    public static final ResourceKey<Feature> PRISMARINE_SPIKE = BOPFeatureUtils.createKey("prismarine_spike");
    public static final ResourceKey<Feature> PUMPKIN_PATCH = BOPFeatureUtils.createKey("pumpkin_patch");
    public static final ResourceKey<Feature> MAPLE_LEAF_LITTER = BOPFeatureUtils.createKey("maple_leaf_litter");
    public static final ResourceKey<Feature> SPARSE_DUNE_GRASS = BOPFeatureUtils.createKey("sparse_dune_grass");
    public static final ResourceKey<Feature> RAINFOREST_CLIFFS_VINES = BOPFeatureUtils.createKey("rainforest_cliffs_vines");
    public static final ResourceKey<Feature> ROOTED_STUMP = BOPFeatureUtils.createKey("rooted_stump");
    public static final ResourceKey<Feature> ROSE_BUSH = BOPFeatureUtils.createKey("rose_bush");
    public static final ResourceKey<Feature> SCATTERED_ROCKS = BOPFeatureUtils.createKey("scattered_rocks");
    public static final ResourceKey<Feature> SCRUB = BOPFeatureUtils.createKey("scrub");
    public static final ResourceKey<Feature> ORIGIN_DANDELION_BONEMEAL = BOPFeatureUtils.createKey("origin_dandelion_bonemeal");
    public static final ResourceKey<Feature> ORIGIN_ROSE_BONEMEAL = BOPFeatureUtils.createKey("origin_rose_bonemeal");
    public static final ResourceKey<Feature> SPROUT_BONEMEAL = BOPFeatureUtils.createKey("sprout_bonemeal");
    public static final ResourceKey<Feature> SUNFLOWER = BOPFeatureUtils.createKey("sunflower");
    public static final ResourceKey<Feature> SHORT_BAMBOO = BOPFeatureUtils.createKey("short_bamboo");
    public static final ResourceKey<Feature> TERMITE_MOUND = BOPFeatureUtils.createKey("termite_mound");
    public static final ResourceKey<Feature> THIN_BAMBOO = BOPFeatureUtils.createKey("thin_bamboo");
    public static final ResourceKey<Feature> SMALL_DRIPLEAF = BOPFeatureUtils.createKey("small_dripleaf");
    public static final ResourceKey<Feature> SMALL_BROWN_MUSHROOM = BOPFeatureUtils.createKey("small_brown_mushroom");
    public static final ResourceKey<Feature> SMALL_RED_MUSHROOM = BOPFeatureUtils.createKey("small_red_mushroom");
    public static final ResourceKey<Feature> SMALL_TOADSTOOL = BOPFeatureUtils.createKey("small_toadstool");
    public static final ResourceKey<Feature> TOADSTOOL_NORMAL = BOPFeatureUtils.createKey("toadstool_normal");
    public static final ResourceKey<Feature> WASTELAND_GRASS = BOPFeatureUtils.createKey("wasteland_grass");
    public static final ResourceKey<Feature> FLOWER_CONIFEROUS_FOREST = BOPFeatureUtils.createKey("flower_coniferous_forest");
    public static final ResourceKey<Feature> FLOWER_DEFAULT_EXTENDED = BOPFeatureUtils.createKey("flower_default_extended");
    public static final ResourceKey<Feature> FLOWER_FIELD = BOPFeatureUtils.createKey("flower_field");
    public static final ResourceKey<Feature> FLOWER_OVERGROWN_GREENS = BOPFeatureUtils.createKey("flower_overgrown_greens");
    public static final ResourceKey<Feature> FLOWER_LAVENDER = BOPFeatureUtils.createKey("flower_lavender");
    public static final ResourceKey<Feature> FLOWER_MOOR = BOPFeatureUtils.createKey("flower_moor");
    public static final ResourceKey<Feature> FLOWER_MYSTIC_GROVE = BOPFeatureUtils.createKey("flower_mystic_grove");
    public static final ResourceKey<Feature> FLOWER_OMINOUS_WOODS = BOPFeatureUtils.createKey("flower_ominous_woods");
    public static final ResourceKey<Feature> FLOWER_ORIGIN_VALLEY = BOPFeatureUtils.createKey("flower_origin_valley");
    public static final ResourceKey<Feature> FLOWER_POPPY = BOPFeatureUtils.createKey("flower_poppy");
    public static final ResourceKey<Feature> FLOWER_RAINFOREST = BOPFeatureUtils.createKey("flower_rainforest");
    public static final ResourceKey<Feature> FLOWER_SEASONAL_FOREST = BOPFeatureUtils.createKey("flower_seasonal_forest");
    public static final ResourceKey<Feature> FLOWER_SHRUBLAND = BOPFeatureUtils.createKey("flower_shrubland");
    public static final ResourceKey<Feature> FLOWER_SNOWBLOSSOM_GROVE = BOPFeatureUtils.createKey("flower_snowblossom_grove");
    public static final ResourceKey<Feature> FLOWER_SNOWY = BOPFeatureUtils.createKey("flower_snowy");
    public static final ResourceKey<Feature> FLOWER_SUBTROPICS = BOPFeatureUtils.createKey("flower_subtropics");
    public static final ResourceKey<Feature> FLOWER_TROPICS = BOPFeatureUtils.createKey("flower_tropics");
    public static final ResourceKey<Feature> FLOWER_VIOLET = BOPFeatureUtils.createKey("flower_violet");
    public static final ResourceKey<Feature> FLOWER_WASTELAND = BOPFeatureUtils.createKey("flower_wasteland");
    public static final ResourceKey<Feature> FLOWER_WETLAND = BOPFeatureUtils.createKey("flower_wetland");
    public static final ResourceKey<Feature> FLOWER_PURPLE_WILDFLOWERS = BOPFeatureUtils.createKey("flower_purple_wildflower");
    public static final ResourceKey<Feature> TREES_AURORAL_GARDEN = BOPFeatureUtils.createKey("trees_auroral_garden");
    public static final ResourceKey<Feature> TREES_BAYOU = BOPFeatureUtils.createKey("trees_bayou");
    public static final ResourceKey<Feature> TREES_BOG = BOPFeatureUtils.createKey("trees_bog");
    public static final ResourceKey<Feature> TREES_CONIFEROUS_FOREST = BOPFeatureUtils.createKey("trees_coniferous_forest");
    public static final ResourceKey<Feature> TREES_DEAD_FOREST = BOPFeatureUtils.createKey("trees_dead_forest");
    public static final ResourceKey<Feature> TREES_DENSE_WOODLAND = BOPFeatureUtils.createKey("trees_dense_woodland");
    public static final ResourceKey<Feature> TREES_DRYLAND = BOPFeatureUtils.createKey("trees_dryland");
    public static final ResourceKey<Feature> TREES_FIELD = BOPFeatureUtils.createKey("trees_field");
    public static final ResourceKey<Feature> TREES_FIELD_FOREST = BOPFeatureUtils.createKey("trees_field_forest");
    public static final ResourceKey<Feature> TREES_FIR_CLEARING = BOPFeatureUtils.createKey("trees_fir_clearing");
    public static final ResourceKey<Feature> TREES_FUNGAL_JUNGLE = BOPFeatureUtils.createKey("trees_fungal_jungle");
    public static final ResourceKey<Feature> TREES_HOT_SPRINGS = BOPFeatureUtils.createKey("trees_hot_springs");
    public static final ResourceKey<Feature> TREES_JADE_CLIFFS = BOPFeatureUtils.createKey("trees_jade_cliffs");
    public static final ResourceKey<Feature> TREES_LAVENDER_FIELD = BOPFeatureUtils.createKey("trees_lavender_field");
    public static final ResourceKey<Feature> TREES_LUSH_DESERT = BOPFeatureUtils.createKey("trees_lush_desert");
    public static final ResourceKey<Feature> TREES_MAPLE_WOODS = BOPFeatureUtils.createKey("trees_maple_woods");
    public static final ResourceKey<Feature> TREES_MEDITERRANEAN_FOREST = BOPFeatureUtils.createKey("tress_mediterranean_forest");
    public static final ResourceKey<Feature> TREES_MUSKEG = BOPFeatureUtils.createKey("trees_muskeg");
    public static final ResourceKey<Feature> TREES_OLD_GROWTH_DEAD_FOREST = BOPFeatureUtils.createKey("trees_old_growth_dead_forest");
    public static final ResourceKey<Feature> TREES_MYSTIC_GROVE = BOPFeatureUtils.createKey("trees_mystic_grove");
    public static final ResourceKey<Feature> TREES_OMINOUS_WOODS = BOPFeatureUtils.createKey("trees_ominous_woods");
    public static final ResourceKey<Feature> TREES_ORCHARD = BOPFeatureUtils.createKey("trees_orchard");
    public static final ResourceKey<Feature> TREES_ORIGIN_VALLEY = BOPFeatureUtils.createKey("trees_origin_valley");
    public static final ResourceKey<Feature> TREES_PRAIRIE = BOPFeatureUtils.createKey("trees_prairie");
    public static final ResourceKey<Feature> TREES_RAINFOREST = BOPFeatureUtils.createKey("trees_rainforest");
    public static final ResourceKey<Feature> TREES_RAINFOREST_CLIFFS = BOPFeatureUtils.createKey("trees_rainforest_cliffs");
    public static final ResourceKey<Feature> TREES_RAINFOREST_FLOODPLAIN = BOPFeatureUtils.createKey("trees_rainforest_floodplain");
    public static final ResourceKey<Feature> TREES_REDWOOD_FOREST = BOPFeatureUtils.createKey("trees_redwood_forest");
    public static final ResourceKey<Feature> TREES_SCRUBLAND = BOPFeatureUtils.createKey("trees_scrubland");
    public static final ResourceKey<Feature> TREES_SEASONAL_FOREST = BOPFeatureUtils.createKey("trees_seasonal_forest");
    public static final ResourceKey<Feature> TREES_SEASONAL_PUMPKIN_PATCH = BOPFeatureUtils.createKey("trees_seasonal_pumpkin_patch");
    public static final ResourceKey<Feature> TREES_SNOWBLOSSOM_GROVE = BOPFeatureUtils.createKey("trees_snowblossom_grove");
    public static final ResourceKey<Feature> TREES_SNOWY_CONIFEROUS_FOREST = BOPFeatureUtils.createKey("trees_snowy_coniferous_forest");
    public static final ResourceKey<Feature> TREES_SNOWY_MAPLE_WOODS = BOPFeatureUtils.createKey("trees_snowy_maple_woods");
    public static final ResourceKey<Feature> TREES_SUBTROPICS = BOPFeatureUtils.createKey("trees_subtropics");
    public static final ResourceKey<Feature> TREES_TROPICS = BOPFeatureUtils.createKey("trees_tropics");
    public static final ResourceKey<Feature> TREES_TUNDRA = BOPFeatureUtils.createKey("trees_tundra");
    public static final ResourceKey<Feature> TREES_WASTELAND = BOPFeatureUtils.createKey("trees_wasteland");
    public static final ResourceKey<Feature> TREES_WETLAND = BOPFeatureUtils.createKey("trees_wetland");

    public static void bootstrap(BootstrapContext<Feature> context)
    {
        HolderGetter<PlacedFeature> placedFeatureGetter = context.lookup(Registries.PLACED_FEATURE);
        HolderGetter<Biome> biomes = context.lookup(Registries.BIOME);
        Holder<BlockStateProvider> belowTrunkProvider = context.lookup(Registries.BLOCK_STATE_PROVIDER).getOrThrow(BlockStateProviders.SOIL_BENEATH_TREE);

        final Holder<PlacedFeature> FANCY_OAK_CHECKED = placedFeatureGetter.getOrThrow(TreePlacements.FANCY_OAK_LEAF_LITTER);
        final Holder<PlacedFeature> JUNGLE_TREE_CHECKED = placedFeatureGetter.getOrThrow(TreePlacements.JUNGLE_TREE_CHECKED);
        final Holder<PlacedFeature> OAK_CHECKED = placedFeatureGetter.getOrThrow(TreePlacements.OAK_CHECKED);
        final Holder<PlacedFeature> OAK_LEAF_LITTER_CHECKED = placedFeatureGetter.getOrThrow(TreePlacements.OAK_LEAF_LITTER);
        final Holder<PlacedFeature> DARK_OAK_CHECKED = placedFeatureGetter.getOrThrow(TreePlacements.DARK_OAK_CHECKED);
        final Holder<PlacedFeature> RED_POPLAR_CHECKED = placedFeatureGetter.getOrThrow(TreePlacements.RED_POPLAR_LEAF_LITTER);
        final Holder<PlacedFeature> ORANGE_POPLAR_CHECKED = placedFeatureGetter.getOrThrow(TreePlacements.ORANGE_POPLAR_LEAF_LITTER);
        final Holder<PlacedFeature> YELLOW_POPLAR_CHECKED = placedFeatureGetter.getOrThrow(TreePlacements.YELLOW_POPLAR_LEAF_LITTER);
        final Holder<PlacedFeature> ACACIA_BUSH_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.ACACIA_BUSH_TREE_CHECKED);
        final Holder<PlacedFeature> ACACIA_TWIGLET_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.ACACIA_TWIGLET_CHECKED);
        final Holder<PlacedFeature> ACACIA_TWIGLET_SMALL_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.ACACIA_TWIGLET_SMALL_CHECKED);
        final Holder<PlacedFeature> ASPEN_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.ASPEN_TREE_CHECKED);
        final Holder<PlacedFeature> AZALEA_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.AZALEA_TREE_CHECKED);
        final Holder<PlacedFeature> BIG_BIRCH_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.BIG_BIRCH_TREE_CHECKED);
        final Holder<PlacedFeature> BIG_FLOWERING_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.BIG_FLOWERING_TREE_CHECKED);
        final Holder<PlacedFeature> BIG_JACARANDA_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.BIG_JACARANDA_TREE_CHECKED);
        final Holder<PlacedFeature> BIG_MAGIC_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.BIG_MAGIC_TREE_CHECKED);
        final Holder<PlacedFeature> BIG_PINK_MAPLE_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.BIG_PINK_MAPLE_TREE_CHECKED);
        final Holder<PlacedFeature> BIG_PINK_MAPLE_TREE_LEAF_LITTER_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.BIG_PINK_MAPLE_TREE_LEAF_LITTER_CHECKED);
        final Holder<PlacedFeature> BIG_MAGENTA_MAPLE_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.BIG_MAGENTA_MAPLE_TREE_CHECKED);
        final Holder<PlacedFeature> BIG_MAGENTA_MAPLE_TREE_LEAF_LITTER_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.BIG_MAGENTA_MAPLE_TREE_LEAF_LITTER_CHECKED);
        final Holder<PlacedFeature> BIG_PURPLE_MAPLE_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.BIG_PURPLE_MAPLE_TREE_CHECKED);
        final Holder<PlacedFeature> BIG_PURPLE_MAPLE_TREE_LEAF_LITTER_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.BIG_PURPLE_MAPLE_TREE_LEAF_LITTER_CHECKED);
        final Holder<PlacedFeature> BIG_OAK_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.BIG_OAK_TREE_CHECKED);
        final Holder<PlacedFeature> BIG_ORIGIN_OAK_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.BIG_ORIGIN_OAK_TREE_CHECKED);
        final Holder<PlacedFeature> BAYOU_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.BAYOU_TREE_CHECKED);
        final Holder<PlacedFeature> BAYOU_TREE_MEDIUM_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.BAYOU_TREE_MEDIUM_CHECKED);
        final Holder<PlacedFeature> DEAD_TREE_WASTELAND_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.DEAD_TREE_WASTELAND_CHECKED);
        final Holder<PlacedFeature> DEAD_TWIGLET_TREE_LEAF_LITTER_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.DEAD_TWIGLET_TREE_LEAF_LITTER_CHECKED);
        final Holder<PlacedFeature> DEAD_TWIGLET_TREE_SHELF_FUNGI_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.DEAD_TWIGLET_TREE_SHELF_FUNGI_CHECKED);
        final Holder<PlacedFeature> DEAD_TWIGLET_TREE_SMALL_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.DEAD_TWIGLET_TREE_SMALL_CHECKED);
        final Holder<PlacedFeature> DYING_TREE_LEAF_LITTER_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.DYING_TREE_LEAF_LITTER_CHECKED);
        final Holder<PlacedFeature> DYING_TREE_WASTELAND_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.DYING_TREE_WASTELAND_CHECKED);
        final Holder<PlacedFeature> FIR_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.FIR_TREE_CHECKED);
        final Holder<PlacedFeature> FIR_TREE_LARGE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.FIR_TREE_LARGE_CHECKED);
        final Holder<PlacedFeature> FIR_TREE_SMALL_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.FIR_TREE_SMALL_CHECKED);
        final Holder<PlacedFeature> FLOWERING_OAK_BUSH_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.FLOWERING_OAK_BUSH_CHECKED);
        final Holder<PlacedFeature> FLOWERING_OAK_TREE_BEES_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.FLOWERING_OAK_TREE_BEES_CHECKED);
        final Holder<PlacedFeature> FLOWERING_OAK_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.FLOWERING_OAK_TREE_CHECKED);
        final Holder<PlacedFeature> GIANT_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.GIANT_TREE_CHECKED);
        final Holder<PlacedFeature> JACARANDA_TREE_BEES_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.JACARANDA_TREE_BEES_CHECKED);
        final Holder<PlacedFeature> JUNGLE_BUSH_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.JUNGLE_BUSH_CHECKED);
        final Holder<PlacedFeature> JUNGLE_TWIGLET_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.JUNGLE_TWIGLET_TREE_CHECKED);
        final Holder<PlacedFeature> MAGIC_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.MAGIC_TREE_CHECKED);
        final Holder<PlacedFeature> MAHOGANY_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.MAHOGANY_TREE_CHECKED);
        final Holder<PlacedFeature> MANGROVE_TWIGLET_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.MANGROVE_TWIGLET_TREE_CHECKED);
        final Holder<PlacedFeature> PINK_MAPLE_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.PINK_MAPLE_TREE_CHECKED);
        final Holder<PlacedFeature> PINK_MAPLE_TREE_LEAF_LITTER_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.PINK_MAPLE_TREE_LEAF_LITTER_CHECKED);
        final Holder<PlacedFeature> MAGENTA_MAPLE_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.MAGENTA_MAPLE_TREE_CHECKED);
        final Holder<PlacedFeature> MAGENTA_MAPLE_TREE_LEAF_LITTER_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.MAGENTA_MAPLE_TREE_LEAF_LITTER_CHECKED);
        final Holder<PlacedFeature> PURPLE_MAPLE_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.PURPLE_MAPLE_TREE_CHECKED);
        final Holder<PlacedFeature> PURPLE_MAPLE_TREE_LEAF_LITTER_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.PURPLE_MAPLE_TREE_LEAF_LITTER_CHECKED);
        final Holder<PlacedFeature> POPLAR_TWIGLET_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.POPLAR_TWIGLET_TREE_CHECKED);
        final Holder<PlacedFeature> OAK_BUSH_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.OAK_BUSH_CHECKED);
        final Holder<PlacedFeature> ORIGIN_OAK_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.ORIGIN_OAK_TREE_CHECKED);
        final Holder<PlacedFeature> PALE_OAK_TWIGLET_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.PALE_OAK_TWIGLET_TREE_CHECKED);
        final Holder<PlacedFeature> PALM_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.PALM_TREE_CHECKED);
        final Holder<PlacedFeature> PALM_TWIGLET_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.PALM_TWIGLET_TREE_CHECKED);
        final Holder<PlacedFeature> PINE_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.PINE_TREE_CHECKED);
        final Holder<PlacedFeature> PINE_TREE_SMALL_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.PINE_TREE_SMALL_CHECKED);
        final Holder<PlacedFeature> REDWOOD_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.REDWOOD_TREE_CHECKED);
        final Holder<PlacedFeature> REDWOOD_TREE_LARGE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.REDWOOD_TREE_LARGE_CHECKED);
        final Holder<PlacedFeature> REDWOOD_TREE_MEDIUM_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.REDWOOD_TREE_MEDIUM_CHECKED);
        final Holder<PlacedFeature> SMALL_DEAD_TREE_LEAF_LITTER_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.SMALL_DEAD_TREE_LEAF_LITTER_CHECKED);
        final Holder<PlacedFeature> SPARSE_ACACIA_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.SPARSE_ACACIA_TREE_CHECKED);
        final Holder<PlacedFeature> SPARSE_OAK_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.SPARSE_OAK_TREE_CHECKED);
        final Holder<PlacedFeature> SPRUCE_BUSH_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.SPRUCE_BUSH_CHECKED);
        final Holder<PlacedFeature> CYPRESS_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.CYPRESS_TREE_CHECKED);
        final Holder<PlacedFeature> SPRUCE_TWIGLET_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.SPRUCE_TWIGLET_TREE_CHECKED);
        final Holder<PlacedFeature> TALL_DEAD_TWIGLET_TREE_LEAF_LITTER_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.TALL_DEAD_TWIGLET_TREE_LEAF_LITTER_CHECKED);
        final Holder<PlacedFeature> TALL_SPRUCE_TREE_BEES_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.TALL_SPRUCE_TREE_BEES_CHECKED);
        final Holder<PlacedFeature> TALL_SPRUCE_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.TALL_SPRUCE_TREE_CHECKED);
        final Holder<PlacedFeature> TALL_TWIGLET_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.TALL_TWIGLET_TREE_CHECKED);
        final Holder<PlacedFeature> TALL_UMBRAN_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.TALL_UMBRAN_TREE_CHECKED);
        final Holder<PlacedFeature> TWIGLET_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.TWIGLET_TREE_CHECKED);
        final Holder<PlacedFeature> UMBRAN_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.UMBRAN_TREE_CHECKED);
        final Holder<PlacedFeature> WILLOW_TREE_CHECKED = placedFeatureGetter.getOrThrow(BOPTreePlacements.WILLOW_TREE_CHECKED);

        register(context, BOPVegetationFeatures.COLD_DESERT_ROCKS, new BlockBlobFeature(Blocks.COBBLESTONE.defaultBlockState(), BlockPredicate.matchesTag(BlockTags.FOREST_ROCK_CAN_PLACE_ON)));
        register(context, BOPVegetationFeatures.PRISMARINE_SPIKE, new BlockBlobFeature(Blocks.PRISMARINE.defaultBlockState(), BlockPredicate.matchesTag(BlockTags.FOREST_ROCK_CAN_PLACE_ON)));
        register(context, BOPVegetationFeatures.HIGH_GRASS, new HighGrassFeature());
        register(context, BOPVegetationFeatures.BIG_DRIPLEAF, new BigDripleafFeature());
        register(context, BOPVegetationFeatures.BIG_PUMPKIN, new BigPumpkinFeature());
        register(context, BOPVegetationFeatures.BRAMBLE, new BrambleFeature());
        register(context, BOPVegetationFeatures.FALLEN_LOG, new FallenLogFeature());
        register(context, BOPVegetationFeatures.FALLEN_FIR_LOG, new FallenFirLogFeature());
        register(context, BOPVegetationFeatures.FALLEN_BIRCH_LOG, new FallenBirchLogFeature());
        register(context, BOPVegetationFeatures.FALLEN_DEAD_LOG, new FallenDeadLogFeature());
        register(context, BOPVegetationFeatures.FALLEN_JACARANDA_LOG, new FallenJacarandaLogFeature());
        register(context, BOPVegetationFeatures.GOLDENROD, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.GOLDENROD)));
        register(context, BOPVegetationFeatures.HOT_SPRING_VENTS, new HotSpringVentFeature());
        register(context, BOPVegetationFeatures.HUGE_CLOVER, new HugeCloverFeature());
        register(context, BOPVegetationFeatures.HUGE_FLOWER, new HugeFlowerFeature());
        register(context, BOPVegetationFeatures.HUGE_LILY_PAD, new HugeLilyPadFeature());
        register(context, BOPVegetationFeatures.HUGE_TOADSTOOL, new HugeToadstoolFeature());
        register(context, BOPVegetationFeatures.DRIPSTONE_SPLATTER, new DripstoneSplatterFeature());
        register(context, BOPVegetationFeatures.MOSS_SPLATTER, new MossSplatterFeature());
        register(context, BOPVegetationFeatures.MYCELIUM_SPLATTER, new MyceliumSplatterFeature());
        register(context, BOPVegetationFeatures.PATCH_BARLEY, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.BARLEY)));
        register(context, BOPVegetationFeatures.PATCH_BLUE_HYDRANGEA, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.BLUE_HYDRANGEA)));
        register(context, BOPVegetationFeatures.PATCH_BUSH, new SimpleBlockFeature(BlockStateProvider.of(Blocks.BUSH)));
        register(context, BOPVegetationFeatures.PATCH_CATTAIL, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.CATTAIL)));
        register(context, BOPVegetationFeatures.PATCH_CLOVER, new SimpleBlockFeature(Holder.direct(new WeightedStateProvider(flowerBedPatchBuilder(BOPBlocks.CLOVER)))));
        register(context, BOPVegetationFeatures.PATCH_DEAD_GRASS, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.DEAD_GRASS)));
        register(context, BOPVegetationFeatures.PATCH_DESERT_GRASS, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.DESERT_GRASS)));
        register(context, BOPVegetationFeatures.PATCH_DRY_GRASS, new SimpleBlockFeature(new WeightedStateProvider(WeightedList.<BlockState>builder().add(Blocks.SHORT_DRY_GRASS.defaultBlockState(), 3).add(Blocks.TALL_DRY_GRASS.defaultBlockState(), 1).build())));
        register(context, BOPVegetationFeatures.PATCH_DUNE_GRASS, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.DUNE_GRASS)));
        register(context, BOPVegetationFeatures.PATCH_FERN, new SimpleBlockFeature(BlockStateProvider.of(Blocks.FERN)));
        register(context, BOPVegetationFeatures.PATCH_FLOWER_BUDS, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.FLOWER_BUD)));
        register(context, BOPVegetationFeatures.PATCH_ICY_IRIS, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.ICY_IRIS)));
        register(context, BOPVegetationFeatures.PATCH_PITCHER_PLANT, new SimpleBlockFeature(BlockStateProvider.of(Blocks.PITCHER_PLANT)));
        register(context, BOPVegetationFeatures.PATCH_LILAC, new SimpleBlockFeature(BlockStateProvider.of(Blocks.LILAC)));
        register(context, BOPVegetationFeatures.PATCH_PEONY, new SimpleBlockFeature(BlockStateProvider.of(Blocks.PEONY)));
        register(context, BOPVegetationFeatures.PATCH_REED, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.REED)));
        register(context, BOPVegetationFeatures.PATCH_SEA_OATS, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.SEA_OATS)));
        register(context, BOPVegetationFeatures.PATCH_SPROUTS, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.SPROUT)));
        register(context, BOPVegetationFeatures.PATCH_TALL_LAVENDER, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.TALL_LAVENDER)));
        register(context, BOPVegetationFeatures.PATCH_TALL_WHITE_LAVENDER, new SimpleBlockFeature(new WeightedStateProvider(WeightedList.<BlockState>builder().add(BOPBlocks.TALL_WHITE_LAVENDER.defaultBlockState(), 3).add(BOPBlocks.WHITE_LAVENDER.defaultBlockState(), 1).build())));
        register(context, BOPVegetationFeatures.PATCH_TINY_CACTUS, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.TINY_CACTUS)));
        register(context, BOPVegetationFeatures.PATCH_TUNDRA_SHRUBS, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.TUNDRA_SHRUB)));
        register(context, BOPVegetationFeatures.PATCH_WATERGRASS, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.WATERGRASS)));
        register(context, BOPVegetationFeatures.PATCH_WATERLILY_FLOWER, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.WATERLILY)));
        register(context, BOPVegetationFeatures.PUMPKIN_PATCH, new PumpkinPatchFeature());

        // Leaf litter
        register(context, BOPVegetationFeatures.MAPLE_LEAF_LITTER, new SimpleBlockFeature(Holder.direct(new WeightedStateProvider(leafLitterPatchBuilder(BOPBlocks.MAPLE_LEAF_LITTER, 1, 3)))));

        register(context, BOPVegetationFeatures.SPARSE_DUNE_GRASS, new SparseDuneGrassFeature());
        register(context, BOPVegetationFeatures.RAINFOREST_CLIFFS_VINES, new RainforestCliffsVinesFeature());
        register(context, BOPVegetationFeatures.ROOTED_STUMP, new RootedStumpFeature());
        register(context, BOPVegetationFeatures.ROSE_BUSH, new SimpleBlockFeature(BlockStateProvider.of(Blocks.ROSE_BUSH)));
        register(context, BOPVegetationFeatures.SCATTERED_ROCKS, new ScatteredRocksFeature());
        register(context, BOPVegetationFeatures.SCRUB, new ScrubFeature());
        register(context, BOPVegetationFeatures.ORIGIN_DANDELION_BONEMEAL, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.ORIGIN_DANDELION.defaultBlockState())));
        register(context, BOPVegetationFeatures.ORIGIN_ROSE_BONEMEAL, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.ORIGIN_ROSE.defaultBlockState())));
        register(context, BOPVegetationFeatures.SPROUT_BONEMEAL, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.SPROUT.defaultBlockState())));
        register(context, BOPVegetationFeatures.SUNFLOWER, new SimpleBlockFeature(BlockStateProvider.of(Blocks.SUNFLOWER)));
        register(context, BOPVegetationFeatures.SHORT_BAMBOO, new ShortBambooFeature());
        register(context, BOPVegetationFeatures.TERMITE_MOUND, new TermiteMoundFeature());
        register(context, BOPVegetationFeatures.THIN_BAMBOO, new ThinBambooFeature());
        register(context, BOPVegetationFeatures.SMALL_DRIPLEAF, new SmallDripleafFeature());
        register(context, BOPVegetationFeatures.SMALL_BROWN_MUSHROOM, new SmallBrownMushroomFeature());
        register(context, BOPVegetationFeatures.SMALL_RED_MUSHROOM, new SmallRedMushroomFeature());
        register(context, BOPVegetationFeatures.SMALL_TOADSTOOL, new SmallToadstoolFeature());
        register(context, BOPVegetationFeatures.TOADSTOOL_NORMAL, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.TOADSTOOL)));
        register(context, BOPVegetationFeatures.WASTELAND_GRASS, new SimpleBlockFeature(new WeightedStateProvider(WeightedList.<BlockState>builder().add(BOPBlocks.DESERT_GRASS.defaultBlockState(), 1).add(BOPBlocks.DEAD_GRASS.defaultBlockState(), 2).build())));

        // Flowers
        register(context, BOPVegetationFeatures.FLOWER_CONIFEROUS_FOREST, new SimpleBlockFeature(new WeightedStateProvider(WeightedList.<BlockState>builder().add(Blocks.CORNFLOWER.defaultBlockState(), 1).add(Blocks.OXEYE_DAISY.defaultBlockState(), 1).add(Blocks.POPPY.defaultBlockState(), 1).add(Blocks.DANDELION.defaultBlockState(), 1))));
        register(context, BOPVegetationFeatures.FLOWER_DEFAULT_EXTENDED, new SimpleBlockFeature(new WeightedStateProvider(WeightedList.<BlockState>builder().add(Blocks.OXEYE_DAISY.defaultBlockState(), 1).add(Blocks.POPPY.defaultBlockState(), 1).add(Blocks.DANDELION.defaultBlockState(), 1))));
        register(context, BOPVegetationFeatures.FLOWER_FIELD, new SimpleBlockFeature(new WeightedStateProvider(WeightedList.<BlockState>builder().add(BOPBlocks.WHITE_LAVENDER.defaultBlockState(), 1).add(Blocks.POPPY.defaultBlockState(), 1).add(Blocks.DANDELION.defaultBlockState(), 1))));
        register(context, BOPVegetationFeatures.FLOWER_OVERGROWN_GREENS, new SimpleBlockFeature(new WeightedStateProvider(WeightedList.<BlockState>builder().add(BOPBlocks.PINK_DAFFODIL.defaultBlockState(), 3).add(Blocks.AZURE_BLUET.defaultBlockState(), 1))));
        register(context, BOPVegetationFeatures.FLOWER_LAVENDER, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.LAVENDER)));
        register(context, BOPVegetationFeatures.FLOWER_MOOR, new SimpleBlockFeature(new WeightedStateProvider(WeightedList.<BlockState>builder().add(Blocks.ALLIUM.defaultBlockState(), 1).add(BOPBlocks.VIOLET.defaultBlockState(), 1))));
        register(context, BOPVegetationFeatures.FLOWER_MYSTIC_GROVE, new SimpleBlockFeature(new WeightedStateProvider(WeightedList.<BlockState>builder().add(BOPBlocks.GLOWFLOWER.defaultBlockState(), 1).add(BOPBlocks.PINK_DAFFODIL.defaultBlockState(), 1).add(Blocks.AZURE_BLUET.defaultBlockState(), 1).add(Blocks.ALLIUM.defaultBlockState(), 1))));
        register(context, BOPVegetationFeatures.FLOWER_OMINOUS_WOODS, new SimpleBlockFeature(BlockStateProvider.of(Blocks.WITHER_ROSE)));
        register(context, BOPVegetationFeatures.FLOWER_ORIGIN_VALLEY, new SimpleBlockFeature(new WeightedStateProvider(WeightedList.<BlockState>builder().add(BOPBlocks.ORIGIN_ROSE.defaultBlockState(), 1).add(BOPBlocks.ORIGIN_DANDELION.defaultBlockState(), 1))));
        register(context, BOPVegetationFeatures.FLOWER_POPPY, new SimpleBlockFeature(BlockStateProvider.of(Blocks.POPPY)));
        register(context, BOPVegetationFeatures.FLOWER_PURPLE_WILDFLOWERS, new SimpleBlockFeature(Holder.direct(new WeightedStateProvider(flowerBedPatchBuilder(BOPBlocks.PURPLE_WILDFLOWERS)))));
        register(context, BOPVegetationFeatures.FLOWER_RAINFOREST, new SimpleBlockFeature(new WeightedStateProvider(WeightedList.<BlockState>builder().add(BOPBlocks.ORANGE_COSMOS.defaultBlockState(), 1).add(Blocks.POPPY.defaultBlockState(), 1).add(Blocks.DANDELION.defaultBlockState(), 1))));
        register(context, BOPVegetationFeatures.FLOWER_SEASONAL_FOREST, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.MARIGOLD)));
        register(context, BOPVegetationFeatures.FLOWER_SHRUBLAND, new SimpleBlockFeature(BlockStateProvider.of(Blocks.ALLIUM)));
        register(context, BOPVegetationFeatures.FLOWER_SNOWBLOSSOM_GROVE, new SimpleBlockFeature(Holder.direct(new WeightedStateProvider(flowerBedPatchBuilder(BOPBlocks.WHITE_PETALS)))));
        register(context, BOPVegetationFeatures.FLOWER_SNOWY, new SimpleBlockFeature(new WeightedStateProvider(WeightedList.<BlockState>builder().add(BOPBlocks.VIOLET.defaultBlockState(), 1).add(Blocks.POPPY.defaultBlockState(), 1).add(Blocks.DANDELION.defaultBlockState(), 1))));
        register(context, BOPVegetationFeatures.FLOWER_SUBTROPICS, new SimpleBlockFeature(new WeightedStateProvider(WeightedList.<BlockState>builder().add(Blocks.LILY_OF_THE_VALLEY.defaultBlockState(), 2).add(Blocks.LILY_OF_THE_VALLEY.defaultBlockState(), 2).add(Blocks.BLUE_ORCHID.defaultBlockState(), 3))));
        register(context, BOPVegetationFeatures.FLOWER_TROPICS, new SimpleBlockFeature(new WeightedStateProvider(WeightedList.<BlockState>builder().add(BOPBlocks.PINK_HIBISCUS.defaultBlockState(), 1).add(Blocks.POPPY.defaultBlockState(), 1).add(Blocks.DANDELION.defaultBlockState(), 1))));
        register(context, BOPVegetationFeatures.FLOWER_VIOLET, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.VIOLET)));
        register(context, BOPVegetationFeatures.FLOWER_WASTELAND, new SimpleBlockFeature(BlockStateProvider.of(BOPBlocks.WILTED_LILY)));
        register(context, BOPVegetationFeatures.FLOWER_WETLAND, new SimpleBlockFeature(new WeightedStateProvider(WeightedList.<BlockState>builder().add(Blocks.BLUE_ORCHID.defaultBlockState(), 1).add(Blocks.POPPY.defaultBlockState(), 1).add(Blocks.DANDELION.defaultBlockState(), 1))));

        register(context, BOPVegetationFeatures.TREES_AURORAL_GARDEN, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(FLOWERING_OAK_BUSH_CHECKED, 0.2F)), PALE_OAK_TWIGLET_TREE_CHECKED));
        register(context, BOPVegetationFeatures.TREES_BAYOU, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(BAYOU_TREE_MEDIUM_CHECKED, 0.3F)), BAYOU_TREE_CHECKED));
        register(context, BOPVegetationFeatures.TREES_BOG, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(SPRUCE_TWIGLET_TREE_CHECKED, 0.4F)), MANGROVE_TWIGLET_TREE_CHECKED));
        register(context, BOPVegetationFeatures.TREES_CONIFEROUS_FOREST, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(YELLOW_POPLAR_CHECKED, 0.015F), new WeightedPlacedFeature(FIR_TREE_CHECKED, 0.33333334F)), FIR_TREE_LARGE_CHECKED));
        register(context, BOPVegetationFeatures.TREES_DEAD_FOREST, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(DYING_TREE_LEAF_LITTER_CHECKED, 0.2F), new WeightedPlacedFeature(TALL_SPRUCE_TREE_CHECKED, 0.3F), new WeightedPlacedFeature(SMALL_DEAD_TREE_LEAF_LITTER_CHECKED, 0.3F), new WeightedPlacedFeature(DEAD_TWIGLET_TREE_LEAF_LITTER_CHECKED, 0.2F)), OAK_LEAF_LITTER_CHECKED));
        register(context, BOPVegetationFeatures.TREES_DENSE_WOODLAND, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(BIG_OAK_TREE_CHECKED, 0.5F)), OAK_CHECKED));
        register(context, BOPVegetationFeatures.TREES_DRYLAND, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(TWIGLET_TREE_CHECKED, 0.4F), new WeightedPlacedFeature(SPARSE_OAK_TREE_CHECKED, 0.2F), new WeightedPlacedFeature(PINE_TREE_SMALL_CHECKED, 0.15F), new WeightedPlacedFeature(PINE_TREE_CHECKED, 0.075F)), ACACIA_TWIGLET_SMALL_CHECKED));
        register(context, BOPVegetationFeatures.TREES_FIELD, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(TALL_SPRUCE_TREE_BEES_CHECKED, 0.1F)), OAK_BUSH_CHECKED));
        register(context, BOPVegetationFeatures.TREES_FIELD_FOREST, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(OAK_BUSH_CHECKED, 0.25F), new WeightedPlacedFeature(PINE_TREE_SMALL_CHECKED, 0.25F)), TALL_SPRUCE_TREE_CHECKED));
        register(context, BOPVegetationFeatures.TREES_FIR_CLEARING, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(OAK_LEAF_LITTER_CHECKED, 0.15F)), FIR_TREE_SMALL_CHECKED));
        register(context, BOPVegetationFeatures.TREES_FUNGAL_JUNGLE, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(OAK_CHECKED, 0.1F), new WeightedPlacedFeature(BIG_OAK_TREE_CHECKED, 0.05F)), JUNGLE_BUSH_CHECKED));
        register(context, BOPVegetationFeatures.TREES_HOT_SPRINGS, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(PINE_TREE_SMALL_CHECKED, 0.1F)), PINE_TREE_CHECKED));
        register(context, BOPVegetationFeatures.TREES_JADE_CLIFFS, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(PINE_TREE_CHECKED, 0.15F)), SPRUCE_BUSH_CHECKED));
        register(context, BOPVegetationFeatures.TREES_LAVENDER_FIELD, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(JACARANDA_TREE_BEES_CHECKED, 0.3F), new WeightedPlacedFeature(BIG_FLOWERING_TREE_CHECKED, 0.15F), new WeightedPlacedFeature(BIG_JACARANDA_TREE_CHECKED, 0.1F)), FLOWERING_OAK_TREE_BEES_CHECKED));
        register(context, BOPVegetationFeatures.TREES_LUSH_DESERT, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(PALM_TREE_CHECKED, 0.1F), new WeightedPlacedFeature(ACACIA_BUSH_TREE_CHECKED, 0.4F), new WeightedPlacedFeature(SPARSE_ACACIA_TREE_CHECKED, 0.2F)), ACACIA_TWIGLET_CHECKED));
        register(context, BOPVegetationFeatures.TREES_MAPLE_WOODS, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(OAK_LEAF_LITTER_CHECKED, 0.05F), new WeightedPlacedFeature(FANCY_OAK_CHECKED, 0.025F), new WeightedPlacedFeature(PINK_MAPLE_TREE_LEAF_LITTER_CHECKED, 0.2F), new WeightedPlacedFeature(PURPLE_MAPLE_TREE_LEAF_LITTER_CHECKED, 0.3F), new WeightedPlacedFeature(BIG_PINK_MAPLE_TREE_LEAF_LITTER_CHECKED, 0.1F), new WeightedPlacedFeature(BIG_PURPLE_MAPLE_TREE_LEAF_LITTER_CHECKED, 0.1F), new WeightedPlacedFeature(BIG_MAGENTA_MAPLE_TREE_LEAF_LITTER_CHECKED, 0.1F)), MAGENTA_MAPLE_TREE_LEAF_LITTER_CHECKED));
        register(context, BOPVegetationFeatures.TREES_MEDITERRANEAN_FOREST, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(SPARSE_OAK_TREE_CHECKED, 0.1F), new WeightedPlacedFeature(DARK_OAK_CHECKED, 0.05F), new WeightedPlacedFeature(CYPRESS_TREE_CHECKED, 0.6F), new WeightedPlacedFeature(FLOWERING_OAK_BUSH_CHECKED, 0.1F)), OAK_BUSH_CHECKED));
        register(context, BOPVegetationFeatures.TREES_MUSKEG, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(TALL_DEAD_TWIGLET_TREE_LEAF_LITTER_CHECKED, 0.2F), new WeightedPlacedFeature(PINE_TREE_SMALL_CHECKED, 0.3F), new WeightedPlacedFeature(DEAD_TWIGLET_TREE_SHELF_FUNGI_CHECKED, 0.5F)), DEAD_TWIGLET_TREE_LEAF_LITTER_CHECKED));
        register(context, BOPVegetationFeatures.TREES_OLD_GROWTH_DEAD_FOREST, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(DYING_TREE_LEAF_LITTER_CHECKED, 0.2F), new WeightedPlacedFeature(DEAD_TWIGLET_TREE_LEAF_LITTER_CHECKED, 0.3F), new WeightedPlacedFeature(TALL_SPRUCE_TREE_CHECKED, 0.1F), new WeightedPlacedFeature(SMALL_DEAD_TREE_LEAF_LITTER_CHECKED, 0.1F), new WeightedPlacedFeature(OAK_LEAF_LITTER_CHECKED, 0.05F)), TALL_DEAD_TWIGLET_TREE_LEAF_LITTER_CHECKED));
        register(context, BOPVegetationFeatures.TREES_MYSTIC_GROVE, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(BIG_FLOWERING_TREE_CHECKED, 0.1F), new WeightedPlacedFeature(BIG_MAGIC_TREE_CHECKED, 0.3F), new WeightedPlacedFeature(GIANT_TREE_CHECKED, 0.025F)), MAGIC_TREE_CHECKED));
        register(context, BOPVegetationFeatures.TREES_OMINOUS_WOODS, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(DEAD_TWIGLET_TREE_LEAF_LITTER_CHECKED, 0.05F), new WeightedPlacedFeature(DYING_TREE_LEAF_LITTER_CHECKED, 0.03F), new WeightedPlacedFeature(TALL_UMBRAN_TREE_CHECKED, 0.7F)), UMBRAN_TREE_CHECKED));
        register(context, BOPVegetationFeatures.TREES_ORCHARD, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(AZALEA_TREE_CHECKED, 0.4F), new WeightedPlacedFeature(BIG_FLOWERING_TREE_CHECKED, 0.1F)), FLOWERING_OAK_TREE_CHECKED));
        register(context, BOPVegetationFeatures.TREES_ORIGIN_VALLEY, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(BIG_ORIGIN_OAK_TREE_CHECKED, 0.1F)), ORIGIN_OAK_TREE_CHECKED));
        register(context, BOPVegetationFeatures.TREES_PRAIRIE, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(BIG_OAK_TREE_CHECKED, 0.1F)), SPARSE_OAK_TREE_CHECKED));
        register(context, BOPVegetationFeatures.TREES_RAINFOREST, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(JUNGLE_TREE_CHECKED, 0.1F)), MAHOGANY_TREE_CHECKED));
        register(context, BOPVegetationFeatures.TREES_RAINFOREST_CLIFFS, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(JUNGLE_TWIGLET_TREE_CHECKED, 0.4F), new WeightedPlacedFeature(BIG_JACARANDA_TREE_CHECKED, 0.1F), new WeightedPlacedFeature(MAHOGANY_TREE_CHECKED, 0.05F)), OAK_BUSH_CHECKED));
        register(context, BOPVegetationFeatures.TREES_RAINFOREST_FLOODPLAIN, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(SPARSE_OAK_TREE_CHECKED, 0.3F), new WeightedPlacedFeature(BIG_OAK_TREE_CHECKED, 0.1F)), OAK_BUSH_CHECKED));
        register(context, BOPVegetationFeatures.TREES_REDWOOD_FOREST, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(REDWOOD_TREE_CHECKED, 0.3f), new WeightedPlacedFeature(REDWOOD_TREE_LARGE_CHECKED, 0.5f)), REDWOOD_TREE_MEDIUM_CHECKED));
        register(context, BOPVegetationFeatures.TREES_SCRUBLAND, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(SPRUCE_TWIGLET_TREE_CHECKED, 0.3F), new WeightedPlacedFeature(TALL_TWIGLET_TREE_CHECKED, 0.1F)), ACACIA_TWIGLET_CHECKED));
        register(context, BOPVegetationFeatures.TREES_SEASONAL_FOREST, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(DARK_OAK_CHECKED, 0.1F), new WeightedPlacedFeature(FIR_TREE_SMALL_CHECKED, 0.2F), new WeightedPlacedFeature(TALL_SPRUCE_TREE_CHECKED, 0.4F), new WeightedPlacedFeature(RED_POPLAR_CHECKED, 0.3F)), BIG_PINK_MAPLE_TREE_LEAF_LITTER_CHECKED));
        register(context, BOPVegetationFeatures.TREES_SEASONAL_PUMPKIN_PATCH, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(OAK_BUSH_CHECKED, 0.2F), new WeightedPlacedFeature(BIG_BIRCH_TREE_CHECKED, 0.1F), new WeightedPlacedFeature(ORANGE_POPLAR_CHECKED, 0.05F)), TWIGLET_TREE_CHECKED));
        register(context, BOPVegetationFeatures.TREES_SNOWBLOSSOM_GROVE, snowblossom(belowTrunkProvider).build());
        register(context, BOPVegetationFeatures.TREES_SNOWY_CONIFEROUS_FOREST, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(RED_POPLAR_CHECKED, 0.03F), new WeightedPlacedFeature(FIR_TREE_CHECKED, 0.4F)), FIR_TREE_LARGE_CHECKED));
        register(context, BOPVegetationFeatures.TREES_SNOWY_MAPLE_WOODS, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(OAK_LEAF_LITTER_CHECKED, 0.05F), new WeightedPlacedFeature(PINK_MAPLE_TREE_CHECKED, 0.1F), new WeightedPlacedFeature(MAGENTA_MAPLE_TREE_CHECKED, 0.3F)), PURPLE_MAPLE_TREE_CHECKED));
        register(context, BOPVegetationFeatures.TREES_SUBTROPICS, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(WILLOW_TREE_CHECKED, 0.05F), new WeightedPlacedFeature(BIG_BIRCH_TREE_CHECKED, 0.1F), new WeightedPlacedFeature(BIG_FLOWERING_TREE_CHECKED, 0.2F), new WeightedPlacedFeature(PALM_TWIGLET_TREE_CHECKED, 0.2F)), BIG_OAK_TREE_CHECKED));
        register(context, BOPVegetationFeatures.TREES_TROPICS, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(JUNGLE_TWIGLET_TREE_CHECKED, 0.3F), new WeightedPlacedFeature(FLOWERING_OAK_TREE_CHECKED, 0.1F)), PALM_TREE_CHECKED));
        register(context, BOPVegetationFeatures.TREES_TUNDRA, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(DEAD_TWIGLET_TREE_SMALL_CHECKED, 0.1F)), POPLAR_TWIGLET_TREE_CHECKED));
        register(context, BOPVegetationFeatures.TREES_WASTELAND, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(DEAD_TREE_WASTELAND_CHECKED, 0.2F)), DYING_TREE_WASTELAND_CHECKED));
        register(context, BOPVegetationFeatures.TREES_WETLAND, new RandomSelectorFeature(ImmutableList.of(new WeightedPlacedFeature(WILLOW_TREE_CHECKED, 0.25F)), TALL_SPRUCE_TREE_CHECKED));
    }

    private static TreeFeature.Builder snowblossom(final Holder<BlockStateProvider> belowTrunkProvider) {
        return new TreeFeature.Builder(
                BlockStateProvider.of(Blocks.CHERRY_LOG),
                new CherryTrunkPlacer(
                        7,
                        1,
                        0,
                        new WeightedListInt(
                                WeightedList.<IntProvider>builder().add(ConstantInt.of(1), 1).add(ConstantInt.of(2), 1).add(ConstantInt.of(3), 1).build()
                        ),
                        UniformInt.of(2, 4),
                        UniformInt.of(-4, -3),
                        UniformInt.of(-1, 0)
                ),
                BlockStateProvider.of(BOPBlocks.SNOWBLOSSOM_LEAVES),
                new CherryFoliagePlacer(ConstantInt.of(4), ConstantInt.of(0), ConstantInt.of(5), 0.25F, 0.5F, 0.16666667F, 0.33333334F),
                new TwoLayersFeatureSize(1, 0, 2),
                belowTrunkProvider
        ).ignoreVines();
    }

//    private static <FC extends FeatureConfiguration, F extends Feature<FC>> RandomPatchConfiguration waterPatchConfiguration(F feature, FC configuration, int tries)
//    {
//        return FeatureUtils.simpleRandomPatchConfiguration(tries, ));
//    }

    public static WeightedList.Builder<BlockState> leafLitterPatchBuilder(Block block, int minState, int maxState)
    {
        return segmentedBlockPatchBuilder(block, minState, maxState, LeafLitterBlock.AMOUNT, LeafLitterBlock.FACING);
    }

    private static WeightedList.Builder<BlockState> segmentedBlockPatchBuilder(Block block, int minState, int maxState, IntegerProperty amountProperty, EnumProperty<Direction> directionProperty)
    {
        WeightedList.Builder<BlockState> segmentedBlockBuild = WeightedList.builder();

        for (int amount = minState; amount <= maxState; amount++) {
            for (Direction direction : Direction.Plane.HORIZONTAL) {
                segmentedBlockBuild.add(block.defaultBlockState().setValue(amountProperty, amount).setValue(directionProperty, direction), 1);
            }
        }

        return segmentedBlockBuild;
    }

//    private static <FC extends FeatureConfiguration, F extends Feature<FC>> RandomPatchConfiguration waterPatchConfiguration(F feature, FC configuration)
//    {
//        return waterPatchConfiguration(feature, configuration, 96);
//    }

    private static WeightedList.Builder<BlockState> flowerBedPatchBuilder(Block p_394149_)
    {
        return segmentedBlockPatchBuilder(p_394149_, 1, 4, FlowerBedBlock.AMOUNT, FlowerBedBlock.FACING);
    }

    private static void register(BootstrapContext<Feature> context, ResourceKey<Feature> key, Feature feature)
    {
        context.register(key, feature);
    }
}
