/*******************************************************************************
 * Copyright 2022, the Glitchfiend Team.
 * All rights reserved.
 ******************************************************************************/
package biomesoplenty.worldgen.feature.misc;

import biomesoplenty.api.block.BOPBlocks;
import biomesoplenty.init.ModTags;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.BaseCoralPlantTypeBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.PipeBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.material.Fluids;
import com.mojang.serialization.MapCodec;

public class TidepoolFeature implements Feature
{
    public static final MapCodec<TidepoolFeature> CODEC = MapCodec.unit(TidepoolFeature::new);

    @Override
    public MapCodec<TidepoolFeature> codec()
    {
        return CODEC;
    }


    @Override
    public boolean place(WorldGenLevel world, ChunkGenerator chunkGenerator, RandomSource rand, BlockPos pos)
    {
        int i = 0;

        BlockState linerBlock;
        switch (rand.nextInt(7))
        {
            default:
            case 0:
                linerBlock = BOPBlocks.WHITE_SANDSTONE.defaultBlockState();
                break;

            case 1:
                linerBlock = Blocks.DEAD_TUBE_CORAL_BLOCK.defaultBlockState();
                break;

            case 2:
                linerBlock = Blocks.DEAD_BRAIN_CORAL_BLOCK.defaultBlockState();
                break;

            case 3:
                linerBlock = Blocks.DEAD_BUBBLE_CORAL_BLOCK.defaultBlockState();
                break;

            case 4:
                linerBlock = Blocks.DEAD_FIRE_CORAL_BLOCK.defaultBlockState();
                break;

            case 5:
                linerBlock = Blocks.DEAD_HORN_CORAL_BLOCK.defaultBlockState();
                break;
        }

        for(int j = 0; j < 96; ++j)
        {
            BlockPos blockpos = pos.offset(rand.nextInt(4) - rand.nextInt(4), rand.nextInt(2) - rand.nextInt(2), rand.nextInt(4) - rand.nextInt(4));
            boolean canPlace = true;

            if (!world.getBlockState(blockpos.above()).is(BlockTags.REPLACEABLE) || !world.getFluidState(blockpos.above()).is(Fluids.EMPTY))
            {
                canPlace = false;
            }

            if (!world.getBlockState(blockpos).is(ModTags.Blocks.TIDEPOOL_REPLACEABLE) || !world.getBlockState(blockpos.below()).is(ModTags.Blocks.TIDEPOOL_REPLACEABLE))
            {
                canPlace = false;
            }

            for (Direction direction : Direction.Plane.HORIZONTAL)
            {
                if (!world.getBlockState(blockpos.relative(direction)).is(ModTags.Blocks.TIDEPOOL_REPLACEABLE) && !world.getFluidState(blockpos.relative(direction)).is(Fluids.WATER))
                {
                    canPlace = false;
                }
            }

            if (canPlace)
            {
                BlockState coral;
                switch (rand.nextInt(12))
                {
                    default:
                    case 0:
                        coral = Blocks.DEAD_TUBE_CORAL.defaultBlockState();
                        break;

                    case 1:
                        coral = Blocks.DEAD_BRAIN_CORAL.defaultBlockState();
                        break;

                    case 2:
                        coral = Blocks.DEAD_BUBBLE_CORAL.defaultBlockState();
                        break;

                    case 3:
                        coral = Blocks.DEAD_FIRE_CORAL.defaultBlockState();
                        break;

                    case 4:
                        coral = Blocks.DEAD_HORN_CORAL.defaultBlockState();
                        break;

                    case 5:
                        coral = Blocks.DEAD_TUBE_CORAL_FAN.defaultBlockState();
                        break;

                    case 6:
                        coral = Blocks.DEAD_BRAIN_CORAL_FAN.defaultBlockState();
                        break;

                    case 7:
                        coral = Blocks.DEAD_BUBBLE_CORAL_FAN.defaultBlockState();
                        break;

                    case 8:
                        coral = Blocks.DEAD_FIRE_CORAL_FAN.defaultBlockState();
                        break;

                    case 9:
                        coral = Blocks.DEAD_HORN_CORAL_FAN.defaultBlockState();
                        break;

                    case 10:
                        coral = BOPBlocks.BARNACLES.defaultBlockState().setValue(PipeBlock.DOWN, true);
                        break;

                    case 11:
                        coral = Blocks.GLOW_LICHEN.defaultBlockState().setValue(PipeBlock.DOWN, true);
                        break;
                }

                world.setBlock(blockpos.below(), linerBlock, 2);

                for (Direction direction : Direction.Plane.HORIZONTAL)
                {
                    if (!world.getFluidState(blockpos.relative(direction)).is(Fluids.WATER))
                    {
                        world.setBlock(blockpos.relative(direction), linerBlock, 2);
                    }
                }

                world.setBlock(blockpos, coral.setValue(BaseCoralPlantTypeBlock.WATERLOGGED, true), 2);
                world.setBlock(blockpos.above(), Blocks.AIR.defaultBlockState(), 2);

                ++i;
            }
        }

        return i > 0;
    }
}
