/*******************************************************************************
 * Copyright 2022, the Glitchfiend Team.
 * All rights reserved.
 ******************************************************************************/
package biomesoplenty.worldgen.placement;

import biomesoplenty.api.block.BOPBlocks;
import biomesoplenty.worldgen.feature.BOPNetherFeatures;
import biomesoplenty.util.worldgen.BOPPlacementUtils;
import com.google.common.collect.ImmutableList;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.data.worldgen.placement.PlacementUtils;
import net.minecraft.data.worldgen.placement.VegetationPlacements;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.Util;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.placement.*;

import java.util.List;

public class BOPNetherPlacements
{
    public static final ResourceKey<PlacedFeature> BLACKSTONE_BULBS = BOPPlacementUtils.createKey("blackstone_bulbs");
    public static final ResourceKey<PlacedFeature> BLACKSTONE_SPINES = BOPPlacementUtils.createKey("blackstone_spines");
    public static final ResourceKey<PlacedFeature> BLOOD_LAKE = BOPPlacementUtils.createKey("blood_lake");
    public static final ResourceKey<PlacedFeature> BLOOD_SPRING = BOPPlacementUtils.createKey("blood_spring");
    public static final ResourceKey<PlacedFeature> ORPIMENT_BUD = BOPPlacementUtils.createKey("orpiment_bud");
    public static final ResourceKey<PlacedFeature> ORPIMENT_CLUSTER = BOPPlacementUtils.createKey("orpiment_cluster");
    public static final ResourceKey<PlacedFeature> ORPIMENT_FIRE = BOPPlacementUtils.createKey("orpiment_fire");
    public static final ResourceKey<PlacedFeature> DEAD_GRASS_45 = BOPPlacementUtils.createKey("dead_grass_45");
    public static final ResourceKey<PlacedFeature> EYEBULB = BOPPlacementUtils.createKey("eyebulb");
    public static final ResourceKey<PlacedFeature> FLESH_TENDON = BOPPlacementUtils.createKey("flesh_tendon");
    public static final ResourceKey<PlacedFeature> FLOWER_UNDERGROWTH = BOPPlacementUtils.createKey("flower_undergrowth");
    public static final ResourceKey<PlacedFeature> HAIR = BOPPlacementUtils.createKey("hair");
    public static final ResourceKey<PlacedFeature> HANGING_FLESH_TENDONS = BOPPlacementUtils.createKey("hanging_flesh_tendons");
    public static final ResourceKey<PlacedFeature> INFERNO_LAVA_LAKE = BOPPlacementUtils.createKey("inferno_lava_lake");
    public static final ResourceKey<PlacedFeature> INFERNO_LAVA_SPRING = BOPPlacementUtils.createKey("inferno_lava_spring");
    public static final ResourceKey<PlacedFeature> INFERNO_SPLATTER = BOPPlacementUtils.createKey("inferno_splatter");
    public static final ResourceKey<PlacedFeature> LARGE_FUMAROLE = BOPPlacementUtils.createKey("large_fumarole");
    public static final ResourceKey<PlacedFeature> LARGE_ROSE_QUARTZ = BOPPlacementUtils.createKey("large_rose_quartz");
    public static final ResourceKey<PlacedFeature> NETHER_BONE_SPINE = BOPPlacementUtils.createKey("nether_bone_spine");
    public static final ResourceKey<PlacedFeature> NETHER_BRAMBLE = BOPPlacementUtils.createKey("nether_bramble");
    public static final ResourceKey<PlacedFeature> NETHER_VINES = BOPPlacementUtils.createKey("nether_vines");
    public static final ResourceKey<PlacedFeature> OBSIDIAN_SPLATTER = BOPPlacementUtils.createKey("obsidian_splatter");
    public static final ResourceKey<PlacedFeature> POROUS_FLESH = BOPPlacementUtils.createKey("porous_flesh");
    public static final ResourceKey<PlacedFeature> PUS_BUBBLES = BOPPlacementUtils.createKey("pus_bubbles");
    public static final ResourceKey<PlacedFeature> SMALL_CRYSTAL = BOPPlacementUtils.createKey("small_crystal");
    public static final ResourceKey<PlacedFeature> SMALL_FUMAROLE = BOPPlacementUtils.createKey("small_fumarole");
    public static final ResourceKey<PlacedFeature> SPROUTS_UNDERGROWTH = BOPPlacementUtils.createKey("sprouts_undergrowth");
    public static final ResourceKey<PlacedFeature> TREES_UNDERGROWTH = BOPPlacementUtils.createKey("trees_undergrowth");

    public static void bootstrap(BootstrapContext<PlacedFeature> context)
    {
        HolderGetter<Feature> configuredFeatureGetter = context.lookup(Registries.FEATURE);

        final Holder<Feature> BLACKSTONE_BULB = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.BLACKSTONE_BULB);
        final Holder<Feature> BLACKSTONE_SPINES = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.BLACKSTONE_SPINES);
        final Holder<Feature> BLOOD_LAKE = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.BLOOD_LAKE);
        final Holder<Feature> BLOOD_SPRING = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.BLOOD_SPRING);
        final Holder<Feature> ORPIMENT_BUD = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.ORPIMENT_BUD);
        final Holder<Feature> ORPIMENT_CLUSTER = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.ORPIMENT_CLUSTER);
        final Holder<Feature> ORPIMENT_FIRE = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.ORPIMENT_FIRE);
        final Holder<Feature> DEAD_GRASS = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.DEAD_GRASS);
        final Holder<Feature> EYEBULB = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.EYEBULB);
        final Holder<Feature> FLESH_TENDON = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.FLESH_TENDON);
        final Holder<Feature> UNDERGROWTH_FLOWERS = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.UNDERGROWTH_FLOWERS);
        final Holder<Feature> HAIR = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.HAIR);
        final Holder<Feature> HANGING_FLESH_TENDON = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.HANGING_FLESH_TENDON);
        final Holder<Feature> INFERNO_LAVA_LAKE = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.INFERNO_LAVA_LAKE);
        final Holder<Feature> INFERNO_LAVA_SPRING = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.INFERNO_LAVA_SPRING);
        final Holder<Feature> INFERNO_SPLATTER = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.INFERNO_SPLATTER);
        final Holder<Feature> LARGE_FUMAROLE = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.LARGE_FUMAROLE);
        final Holder<Feature> LARGE_ROSE_QUARTZ = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.LARGE_ROSE_QUARTZ);
        final Holder<Feature> NETHER_BONE_SPINE = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.NETHER_BONE_SPINE);
        final Holder<Feature> NETHER_BRAMBLE = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.NETHER_BRAMBLE);
        final Holder<Feature> NETHER_VINES = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.NETHER_VINES);
        final Holder<Feature> OBSIDIAN_SPLATTER = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.OBSIDIAN_SPLATTER);
        final Holder<Feature> POROUS_FLESH = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.POROUS_FLESH);
        final Holder<Feature> PUS_BUBBLES = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.PUS_BUBBLES);
        final Holder<Feature> SMALL_CRYSTAL = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.SMALL_CRYSTAL);
        final Holder<Feature> SMALL_FUMAROLE = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.SMALL_FUMAROLE);
        final Holder<Feature> SPROUTS_UNDERGROWTH = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.SPROUTS_UNDERGROWTH);
        final Holder<Feature> TREES_UNDERGROWTH = configuredFeatureGetter.getOrThrow(BOPNetherFeatures.TREES_UNDERGROWTH);

        register(context, BOPNetherPlacements.BLACKSTONE_BULBS, BLACKSTONE_BULB, Util.copyAndAdd(netherSquaredWithCount(12), new PlacementModifier[]{CountPlacement.of(96), OffsetPlacement.ofTriangle(7, 3), BlockPredicateFilter.forPredicate(BlockPredicate.ONLY_IN_AIR_PREDICATE)}));
        register(context, BOPNetherPlacements.BLACKSTONE_SPINES, BLACKSTONE_SPINES, Util.copyAndAdd(netherSquaredWithCount(100), new PlacementModifier[]{CountPlacement.of(96), OffsetPlacement.ofTriangle(7, 3), BlockPredicateFilter.forPredicate(BlockPredicate.ONLY_IN_AIR_PREDICATE)}));
        register(context, BOPNetherPlacements.BLOOD_LAKE, BLOOD_LAKE, List.of(CountPlacement.of(5), InSquarePlacement.spread(), PlacementUtils.FULL_RANGE, BiomeFilter.biome()));
        register(context, BOPNetherPlacements.BLOOD_SPRING, BLOOD_SPRING, List.of(CountPlacement.of(12), InSquarePlacement.spread(), PlacementUtils.RANGE_4_4, BiomeFilter.biome()));
        register(context, BOPNetherPlacements.ORPIMENT_BUD, ORPIMENT_BUD, Util.copyAndAdd(netherSquaredWithCount(175), new PlacementModifier[]{CountPlacement.of(96), OffsetPlacement.ofTriangle(7, 3), BlockPredicateFilter.forPredicate(BlockPredicate.ONLY_IN_AIR_PREDICATE)}));
        register(context, BOPNetherPlacements.ORPIMENT_CLUSTER, ORPIMENT_CLUSTER, Util.copyAndAdd(netherSquaredWithCount(14), new PlacementModifier[]{CountPlacement.of(96), OffsetPlacement.ofTriangle(7, 3), BlockPredicateFilter.forPredicate(BlockPredicate.ONLY_IN_AIR_PREDICATE)}));
        register(context, BOPNetherPlacements.ORPIMENT_FIRE, ORPIMENT_FIRE, firePlacement(BOPBlocks.ORPIMENT));
        register(context, BOPNetherPlacements.DEAD_GRASS_45, DEAD_GRASS, Util.copyAndAdd(netherSquaredWithCount(45), new PlacementModifier[]{CountPlacement.of(96), OffsetPlacement.ofTriangle(7, 3), BlockPredicateFilter.forPredicate(BlockPredicate.ONLY_IN_AIR_PREDICATE)}));
        register(context, BOPNetherPlacements.EYEBULB, EYEBULB, Util.copyAndAdd(nether1010SquaredWithCount(3), new PlacementModifier[]{CountPlacement.of(96), OffsetPlacement.ofTriangle(7, 3), BlockPredicateFilter.forPredicate(BlockPredicate.ONLY_IN_AIR_PREDICATE)}));
        register(context, BOPNetherPlacements.FLESH_TENDON, FLESH_TENDON, List.of(CountPlacement.of(50), InSquarePlacement.spread(), PlacementUtils.FULL_RANGE, BiomeFilter.biome()));
        register(context, BOPNetherPlacements.FLOWER_UNDERGROWTH, UNDERGROWTH_FLOWERS, Util.copyAndAdd(netherSquaredWithCount(8), new PlacementModifier[]{CountPlacement.of(96), OffsetPlacement.ofTriangle(7, 3), BlockPredicateFilter.forPredicate(BlockPredicate.ONLY_IN_AIR_PREDICATE)}));
        register(context, BOPNetherPlacements.HAIR, HAIR, Util.copyAndAdd(netherSquaredWithCount(22), new PlacementModifier[]{CountPlacement.of(96), OffsetPlacement.ofTriangle(7, 3), BlockPredicateFilter.forPredicate(BlockPredicate.ONLY_IN_AIR_PREDICATE)}));
        register(context, BOPNetherPlacements.HANGING_FLESH_TENDONS, HANGING_FLESH_TENDON, List.of(CountPlacement.of(85), InSquarePlacement.spread(), PlacementUtils.FULL_RANGE, BiomeFilter.biome()));
        register(context, BOPNetherPlacements.INFERNO_LAVA_LAKE, INFERNO_LAVA_LAKE, List.of(CountOnEveryLayerPlacement.of(3), BiomeFilter.biome()));
        register(context, BOPNetherPlacements.INFERNO_LAVA_SPRING, INFERNO_LAVA_SPRING, List.of(CountPlacement.of(20), InSquarePlacement.spread(), PlacementUtils.RANGE_4_4, BiomeFilter.biome()));
        register(context, BOPNetherPlacements.INFERNO_SPLATTER, INFERNO_SPLATTER, List.of(CountPlacement.of(5), InSquarePlacement.spread(), PlacementUtils.FULL_RANGE, BiomeFilter.biome()));
        register(context, BOPNetherPlacements.LARGE_FUMAROLE, LARGE_FUMAROLE, List.of(CountPlacement.of(125), InSquarePlacement.spread(), PlacementUtils.FULL_RANGE, BiomeFilter.biome()));
        register(context, BOPNetherPlacements.LARGE_ROSE_QUARTZ, LARGE_ROSE_QUARTZ, List.of(CountPlacement.of(6), InSquarePlacement.spread(), PlacementUtils.FULL_RANGE, BiomeFilter.biome()));
        register(context, BOPNetherPlacements.NETHER_BONE_SPINE, NETHER_BONE_SPINE, List.of(CountPlacement.of(3), InSquarePlacement.spread(), PlacementUtils.FULL_RANGE, BiomeFilter.biome()));
        register(context, BOPNetherPlacements.NETHER_BRAMBLE, NETHER_BRAMBLE, List.of(CountPlacement.of(50), InSquarePlacement.spread(), PlacementUtils.FULL_RANGE, BiomeFilter.biome()));
        register(context, BOPNetherPlacements.NETHER_VINES, NETHER_VINES, List.of(CountPlacement.of(150), InSquarePlacement.spread(), PlacementUtils.FULL_RANGE, BiomeFilter.biome()));
        register(context, BOPNetherPlacements.OBSIDIAN_SPLATTER, OBSIDIAN_SPLATTER, List.of(CountPlacement.of(16), InSquarePlacement.spread(), PlacementUtils.FULL_RANGE, BiomeFilter.biome()));
        register(context, BOPNetherPlacements.POROUS_FLESH, POROUS_FLESH, List.of(CountPlacement.of(80), InSquarePlacement.spread(), PlacementUtils.RANGE_10_10, BiomeFilter.biome()));
        register(context, BOPNetherPlacements.PUS_BUBBLES, PUS_BUBBLES, Util.copyAndAdd(nether1010SquaredWithCount(12), new PlacementModifier[]{CountPlacement.of(96), OffsetPlacement.ofTriangle(7, 3), BlockPredicateFilter.forPredicate(BlockPredicate.ONLY_IN_AIR_PREDICATE)}));
        register(context, BOPNetherPlacements.SMALL_CRYSTAL, SMALL_CRYSTAL, List.of(CountPlacement.of(100), InSquarePlacement.spread(), PlacementUtils.FULL_RANGE, BiomeFilter.biome()));
        register(context, BOPNetherPlacements.SMALL_FUMAROLE, SMALL_FUMAROLE, List.of(CountPlacement.of(40), InSquarePlacement.spread(), PlacementUtils.FULL_RANGE, BiomeFilter.biome()));
        register(context, BOPNetherPlacements.SPROUTS_UNDERGROWTH, SPROUTS_UNDERGROWTH, Util.copyAndAdd(netherSquaredWithCount(75), new PlacementModifier[]{CountPlacement.of(96), OffsetPlacement.ofTriangle(7, 3), BlockPredicateFilter.forPredicate(BlockPredicate.ONLY_IN_AIR_PREDICATE)}));
        register(context, BOPNetherPlacements.TREES_UNDERGROWTH, TREES_UNDERGROWTH, netherTreePlacement(PlacementUtils.countExtra(40, 0.2F, 1)));
    }

    private static List<PlacementModifier> firePlacement(Block onlyOnBlock) {
        return List.of(CountPlacement.of(UniformInt.of(0, 5)), InSquarePlacement.spread(), PlacementUtils.RANGE_4_4, BiomeFilter.biome(), CountPlacement.of(96), OffsetPlacement.ofTriangle(7, 3), BlockPredicateFilter.forPredicate(BlockPredicate.allOf(BlockPredicate.ONLY_IN_AIR_PREDICATE, BlockPredicate.matchesBlocks(Direction.DOWN.getUnitVec3i(), List.of(onlyOnBlock)))));
    }

    public static List<PlacementModifier> netherSquaredWithCount(int count) {
        return List.of(CountPlacement.of(count), InSquarePlacement.spread(), PlacementUtils.FULL_RANGE, BiomeFilter.biome());
    }

    public static List<PlacementModifier> nether1010SquaredWithCount(int count) {
        return List.of(CountPlacement.of(count), InSquarePlacement.spread(), PlacementUtils.RANGE_10_10, BiomeFilter.biome());
    }

    private static ImmutableList.Builder<PlacementModifier> netherTreePlacementBase(PlacementModifier modifier)
    {
        PlacementModifier treeThreshold = SurfaceWaterDepthFilter.forMaxDepth(0);
        return ImmutableList.<PlacementModifier>builder().add(modifier).add(InSquarePlacement.spread()).add(treeThreshold).add(PlacementUtils.FULL_RANGE).add(BiomeFilter.biome());
    }

    private static List<PlacementModifier> netherTreePlacement(PlacementModifier modifier)
    {
        return netherTreePlacementBase(modifier).build();
    }

    private static List<PlacementModifier> netherTreePlacement(PlacementModifier modifier, Block survivalTestBlock)
    {
        return netherTreePlacementBase(modifier).add(BlockPredicateFilter.forPredicate(BlockPredicate.wouldSurvive(survivalTestBlock))).build();
    }

    protected static void register(BootstrapContext<PlacedFeature> context, ResourceKey<PlacedFeature> placedFeatureKey, Holder<Feature> configuredFeature, PlacementModifier... modifiers)
    {
        register(context, placedFeatureKey, configuredFeature, List.of(modifiers));
    }

    protected static void register(BootstrapContext<PlacedFeature> context, ResourceKey<PlacedFeature> placedFeatureKey, Holder<Feature> configuredFeature, List<PlacementModifier> modifiers)
    {
        context.register(placedFeatureKey, new PlacedFeature(configuredFeature, modifiers));
    }
}
