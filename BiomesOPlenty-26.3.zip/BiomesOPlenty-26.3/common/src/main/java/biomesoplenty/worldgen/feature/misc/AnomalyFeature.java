/*******************************************************************************
 * Copyright 2022, the Glitchfiend Team.
 * All rights reserved.
 ******************************************************************************/
package biomesoplenty.worldgen.feature.misc;

import biomesoplenty.api.block.BOPBlocks;
import biomesoplenty.block.AnomalyBlock;
import biomesoplenty.init.ModTags;
import biomesoplenty.util.SimpleBlockPredicate;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.VegetationBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.feature.Feature;
import com.mojang.serialization.MapCodec;

public class AnomalyFeature implements Feature
{
    protected SimpleBlockPredicate placeOn = (world, pos) -> world.getBlockState(pos).getBlock() == Blocks.END_STONE || world.getBlockState(pos).getBlock() == BOPBlocks.UNMAPPED_END_STONE;
    protected SimpleBlockPredicate replace = (world, pos) -> world.getBlockState(pos).is(BlockTags.REPLACEABLE_BY_TREES) || world.getBlockState(pos).getBlock() instanceof VegetationBlock || world.getBlockState(pos).is(ModTags.Blocks.NULL_REPLACEABLE);

    public static final MapCodec<AnomalyFeature> CODEC = MapCodec.unit(AnomalyFeature::new);

    @Override
    public MapCodec<AnomalyFeature> codec()
    {
        return CODEC;
    }


    @Override
    public boolean place(WorldGenLevel world, ChunkGenerator chunkGenerator, RandomSource rand, BlockPos startPos)
    {
        while (startPos.getY() >= world.getMinY()+1 && !this.placeOn.matches(world, startPos)) {startPos = startPos.below();}

        if (!this.placeOn.matches(world, startPos.offset(0, 0, 0)))
        {
            // Abandon if we can't place the tree on this block
            return false;
        }

        int size = rand.nextInt(4) + 3;
        int anomalyHeight = rand.nextInt(8) + 2;

        if (!this.checkSpace(world, startPos, size, anomalyHeight))
        {
            // Abandon if there isn't enough room
            return false;
        }

        BlockPos pos = startPos;

        for (int y = 6; y > -128; y--)
        {
            for (int x = -3; x <= size+3; x++)
            {
                for (int z = -3; z <= size+3; z++)
                {
                    if (x == -3 || x == size+3 || z == -3 || z == size+3)
                    {
                        if (!((x == -3 || x == size+3) && (z == -3 || z == size+3)))
                        {
                            if (rand.nextInt(4) == 0 && world.getBlockState(pos.offset(x,y,z)).getBlock() != BOPBlocks.NULL_BLOCK)
                            {
                                if (world.getBlockState(pos.offset(x, y, z)).is(BlockTags.REPLACEABLE_BY_TREES))
                                {
                                    this.setBlock(world, pos.offset(x,y,z), Blocks.AIR.defaultBlockState());
                                }
                                else
                                {
                                    this.setBlock(world, pos.offset(x,y,z), BOPBlocks.NULL_END_STONE.defaultBlockState());
                                }
                            }
                        }
                    }
                    else if (x == -2 || x == size+2 || z == -2 || z == size+2)
                    {
                        if (!((x == -2 || x == size+2) && (z == -2 || z == size+2)))
                        {
                            if (world.getBlockState(pos.offset(x,y,z)).getBlock() != BOPBlocks.NULL_BLOCK)
                            {
                                if (world.getBlockState(pos.offset(x, y, z)).is(BlockTags.REPLACEABLE_BY_TREES))
                                {
                                    this.setBlock(world, pos.offset(x,y,z), Blocks.AIR.defaultBlockState());
                                }
                                else
                                {
                                    if (rand.nextInt(4) == 0)
                                    {
                                        this.setBlock(world, pos.offset(x,y,z), BOPBlocks.NULL_BLOCK.defaultBlockState());
                                    }
                                    else
                                    {
                                        this.setBlock(world, pos.offset(x,y,z), BOPBlocks.NULL_END_STONE.defaultBlockState());
                                    }
                                }
                            }
                        }
                    }
                    else if (x == -1 || x == size+1 || z == -1 || z == size+1)
                    {
                        if ((x == -1 || x == size+1) && (z == -1 || z == size+1))
                        {
                            if (world.getBlockState(pos.offset(x, y, z)).is(BlockTags.REPLACEABLE_BY_TREES))
                            {
                                this.setBlock(world, pos.offset(x,y,z), Blocks.AIR.defaultBlockState());
                            }
                            else
                            {
                                this.setBlock(world, pos.offset(x,y,z), BOPBlocks.NULL_END_STONE.defaultBlockState());
                            }
                        }
                        else
                        {
                            if (world.getBlockState(pos.offset(x, y, z)).is(BlockTags.REPLACEABLE_BY_TREES))
                            {
                                this.setBlock(world, pos.offset(x,y,z), Blocks.AIR.defaultBlockState());
                            }
                            else
                            {
                                this.setBlock(world, pos.offset(x,y,z), BOPBlocks.NULL_BLOCK.defaultBlockState());
                            }
                        }
                    }
                    else
                    {
                        this.setBlock(world, pos.offset(x,y,z), Blocks.AIR.defaultBlockState());
                    }
                }
            }
        }

        for (int y = 0; y <= size; y++)
        {
            for (int x = 0; x <= size; x++)
            {
                for (int z = 0; z <= size; z++)
                {
                    AnomalyBlock.AnomalyType type = AnomalyBlock.AnomalyType.STABLE;
                    if (y == 0 || y == size || x == 0 || x == size || z == 0 || z == size)
                    {
                        switch (rand.nextInt(5))
                        {
                            default:
                            case 0:
                                type = AnomalyBlock.AnomalyType.VOLATILE;
                                break;

                            case 1:
                                type = AnomalyBlock.AnomalyType.QUIRKY;
                                break;

                            case 2:
                                type = AnomalyBlock.AnomalyType.UNSTABLE;
                                break;
                        }
                    }

                    world.setBlock(pos.offset(x,anomalyHeight+y,z), BOPBlocks.ANOMALY.defaultBlockState().setValue(AnomalyBlock.ANOMALY_TYPE, type), 2);
                }
            }
        }

        return true;
    }

    public boolean setBlock(WorldGenLevel world, BlockPos pos, BlockState state)
    {
        if (this.replace.matches(world, pos))
        {
            Feature.super.setBlock(world, pos, state);
            return true;
        }
        return false;
    }

    public boolean checkSpace(WorldGenLevel world, BlockPos pos, int size, int anomalyHeight)
    {
        for (int y = 0; y <= size; y++)
        {
            for (int x = 0; x <= size; x++)
            {
                for (int z = 0; z <= size; z++)
                {
                    BlockPos pos1 = pos.offset(x, anomalyHeight+y, z);
                    if (pos1.getY() >= 255 || (!world.getBlockState(pos1).isAir() && world.getBlockState(pos1).getBlock() != BOPBlocks.ANOMALY))
                    {
                        return false;
                    }
                }
            }
        }
        return true;
    }
}
