/*******************************************************************************
 * Copyright 2022, the Glitchfiend Team.
 * All rights reserved.
 ******************************************************************************/
package biomesoplenty.worldgen.feature.misc;

import biomesoplenty.api.block.BOPBlocks;
import biomesoplenty.init.ModTags;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.MultifaceBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.feature.Feature;
import com.mojang.serialization.MapCodec;

public class BarnacleFeature implements Feature
{
    public static final MapCodec<BarnacleFeature> CODEC = MapCodec.unit(BarnacleFeature::new);

    @Override
    public MapCodec<BarnacleFeature> codec()
    {
        return CODEC;
    }


    @Override
    public boolean place(WorldGenLevel worldIn, ChunkGenerator chunkGenerator, RandomSource rand, BlockPos pos)
    {
        int i = 0;
        int j = rand.nextInt(8 - 2) + 2;

        for (int k = pos.getX() - j; k <= pos.getX() + j; ++k)
        {
            for (int l = pos.getZ() - j; l <= pos.getZ() + j; ++l)
            {
                int i1 = k - pos.getX();
                int j1 = l - pos.getZ();
                if (i1 * i1 + j1 * j1 <= j * j)
                {
                    for (int k1 = pos.getY() - j; k1 <= pos.getY() + j; ++k1)
                    {
                        BlockPos blockpos = new BlockPos(k, k1, l);
                        BlockState blockstate = worldIn.getBlockState(blockpos);
                        BlockState barnaclestate = BOPBlocks.BARNACLES.defaultBlockState();

                        int faces = 0;

                        for (Direction direction : Direction.values())
                        {
                            BlockState blockstate1 = worldIn.getBlockState(blockpos.relative(direction));
                            if (rand.nextInt(4) == 0 && (blockstate1 == Blocks.END_STONE.defaultBlockState() || blockstate1 == BOPBlocks.UNMAPPED_END_STONE.defaultBlockState() || blockstate1 == BOPBlocks.NULL_END_STONE.defaultBlockState() || blockstate1 == BOPBlocks.ALGAL_END_STONE.defaultBlockState() || blockstate1 == BOPBlocks.WHITE_SAND.defaultBlockState() || blockstate1 == BOPBlocks.WHITE_SANDSTONE.defaultBlockState() || blockstate1.is(ModTags.Blocks.DEAD_CORAL_BLOCKS)))
                            {
                                barnaclestate = barnaclestate.setValue(MultifaceBlock.getFaceProperty(direction), true);
                                faces++;
                            }
                        }

                        if (blockstate.isAir() && faces > 0)
                        {
                            worldIn.setBlock(blockpos, barnaclestate, 2);

                            ++i;
                            break;
                        }
                    }
                }
            }
        }

        return i > 0;
    }
}
