/*******************************************************************************
 * Copyright 2022, the Glitchfiend Team.
 * All rights reserved.
 ******************************************************************************/
package biomesoplenty.init;

import biomesoplenty.api.block.BOPBlocks;
import biomesoplenty.api.item.BOPItems;
import com.mojang.authlib.minecraft.client.MinecraftClient;
import glitchcore.util.BlockHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.dispenser.BlockSource;
import net.minecraft.core.dispenser.DefaultDispenseItemBehavior;
import net.minecraft.core.dispenser.DispenseItemBehavior;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.phys.BlockHitResult;

import java.util.*;
import java.util.logging.Logger;

import static glitchcore.util.BlockHelper.*;
import net.minecraft.world.level.storage.loot.providers.number.ints.ContextIntProviders;
import net.minecraft.world.level.storage.loot.providers.number.ints.ContextIntProvider;
import net.minecraft.resources.ResourceKey;

public class ModVanillaCompat
{
    public static void setup()
    {
        //Dispenser Behavior
        DispenseItemBehavior dispenseBucketBehavior = new DefaultDispenseItemBehavior() {
            private final DefaultDispenseItemBehavior defaultDispenseItemBehavior = new DefaultDispenseItemBehavior();

            public ItemStack execute(BlockSource p_123561_, ItemStack p_123562_) {
                DispensibleContainerItem dispensiblecontaineritem = (DispensibleContainerItem)p_123562_.getItem();
                BlockPos blockpos = p_123561_.pos().relative(p_123561_.state().getValue(DispenserBlock.FACING));
                Level level = p_123561_.level();
                if (dispensiblecontaineritem.emptyContents((Player)null, level, blockpos, (BlockHitResult)null)) {
                    dispensiblecontaineritem.checkExtraContent((Player)null, level, p_123562_, blockpos);
                    return new ItemStack(Items.BUCKET);
                } else {
                    return this.defaultDispenseItemBehavior.dispense(p_123561_, p_123562_);
                }
            }
        };

        DispenserBlock.registerBehavior(BOPItems.BLOOD_BUCKET, dispenseBucketBehavior);
        DispenserBlock.registerBehavior(BOPItems.LIQUID_NULL_BUCKET, dispenseBucketBehavior);

        //Flammability
        registerFlammable(BOPBlocks.FLOWERING_OAK_LEAVES, 30, 60);
        registerFlammable(BOPBlocks.CYPRESS_LEAVES, 30, 60);
        registerFlammable(BOPBlocks.SNOWBLOSSOM_LEAVES, 30, 60);
        registerFlammable(BOPBlocks.ORIGIN_OAK_LEAVES, 30, 60);
        registerFlammable(BOPBlocks.ORIGIN_OAK_LOG, 5, 5);
        registerFlammable(BOPBlocks.ORIGIN_OAK_WOOD, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_ORIGIN_OAK_LOG, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_ORIGIN_OAK_WOOD, 5, 5);
        registerFlammable(BOPBlocks.ORIGIN_OAK_PLANKS, 5, 20);
        registerFlammable(BOPBlocks.ORIGIN_OAK_SLAB, 5, 20);
        registerFlammable(BOPBlocks.ORIGIN_OAK_STAIRS, 5, 20);
        registerFlammable(BOPBlocks.ORIGIN_OAK_FENCE, 5, 20);
        registerFlammable(BOPBlocks.ORIGIN_OAK_FENCE_GATE, 5, 20);
        registerFlammable(BOPBlocks.ORIGIN_OAK_SHELF, 30, 20);
        registerFlammable(BOPBlocks.FIR_LEAVES, 30, 60);
        registerFlammable(BOPBlocks.FIR_LOG, 5, 5);
        registerFlammable(BOPBlocks.FIR_WOOD, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_FIR_LOG, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_FIR_WOOD, 5, 5);
        registerFlammable(BOPBlocks.FIR_PLANKS, 5, 20);
        registerFlammable(BOPBlocks.FIR_SLAB, 5, 20);
        registerFlammable(BOPBlocks.FIR_STAIRS, 5, 20);
        registerFlammable(BOPBlocks.FIR_FENCE, 5, 20);
        registerFlammable(BOPBlocks.FIR_FENCE_GATE, 5, 20);
        registerFlammable(BOPBlocks.FIR_SHELF, 30, 20);
        registerFlammable(BOPBlocks.PINE_LEAVES, 30, 60);
        registerFlammable(BOPBlocks.PINE_LOG, 5, 5);
        registerFlammable(BOPBlocks.PINE_WOOD, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_PINE_LOG, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_PINE_WOOD, 5, 5);
        registerFlammable(BOPBlocks.PINE_PLANKS, 5, 20);
        registerFlammable(BOPBlocks.PINE_SLAB, 5, 20);
        registerFlammable(BOPBlocks.PINE_STAIRS, 5, 20);
        registerFlammable(BOPBlocks.PINE_FENCE, 5, 20);
        registerFlammable(BOPBlocks.PINE_FENCE_GATE, 5, 20);
        registerFlammable(BOPBlocks.PINE_SHELF, 30, 20);
        registerFlammable(BOPBlocks.PINK_MAPLE_LEAVES, 30, 60);
        registerFlammable(BOPBlocks.MAGENTA_MAPLE_LEAVES, 30, 60);
        registerFlammable(BOPBlocks.PURPLE_MAPLE_LEAVES, 30, 60);
        registerFlammable(BOPBlocks.MAPLE_LOG, 5, 5);
        registerFlammable(BOPBlocks.MAPLE_WOOD, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_MAPLE_LOG, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_MAPLE_WOOD, 5, 5);
        registerFlammable(BOPBlocks.MAPLE_PLANKS, 5, 20);
        registerFlammable(BOPBlocks.MAPLE_SLAB, 5, 20);
        registerFlammable(BOPBlocks.MAPLE_STAIRS, 5, 20);
        registerFlammable(BOPBlocks.MAPLE_FENCE, 5, 20);
        registerFlammable(BOPBlocks.MAPLE_FENCE_GATE, 5, 20);
        registerFlammable(BOPBlocks.MAPLE_SHELF, 30, 20);
        registerFlammable(BOPBlocks.REDWOOD_LEAVES, 30, 60);
        registerFlammable(BOPBlocks.REDWOOD_LOG, 5, 5);
        registerFlammable(BOPBlocks.REDWOOD_WOOD, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_REDWOOD_LOG, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_REDWOOD_WOOD, 5, 5);
        registerFlammable(BOPBlocks.REDWOOD_PLANKS, 5, 20);
        registerFlammable(BOPBlocks.REDWOOD_SLAB, 5, 20);
        registerFlammable(BOPBlocks.REDWOOD_STAIRS, 5, 20);
        registerFlammable(BOPBlocks.REDWOOD_FENCE, 5, 20);
        registerFlammable(BOPBlocks.REDWOOD_FENCE_GATE, 5, 20);
        registerFlammable(BOPBlocks.REDWOOD_SHELF, 30, 20);
        registerFlammable(BOPBlocks.MAHOGANY_LEAVES, 30, 60);
        registerFlammable(BOPBlocks.MAHOGANY_LOG, 5, 5);
        registerFlammable(BOPBlocks.MAHOGANY_WOOD, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_MAHOGANY_LOG, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_MAHOGANY_WOOD, 5, 5);
        registerFlammable(BOPBlocks.MAHOGANY_PLANKS, 5, 20);
        registerFlammable(BOPBlocks.MAHOGANY_SLAB, 5, 20);
        registerFlammable(BOPBlocks.MAHOGANY_STAIRS, 5, 20);
        registerFlammable(BOPBlocks.MAHOGANY_FENCE, 5, 20);
        registerFlammable(BOPBlocks.MAHOGANY_FENCE_GATE, 5, 20);
        registerFlammable(BOPBlocks.MAHOGANY_SHELF, 30, 20);
        registerFlammable(BOPBlocks.JACARANDA_LEAVES, 30, 60);
        registerFlammable(BOPBlocks.JACARANDA_LOG, 5, 5);
        registerFlammable(BOPBlocks.JACARANDA_WOOD, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_JACARANDA_LOG, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_JACARANDA_WOOD, 5, 5);
        registerFlammable(BOPBlocks.JACARANDA_PLANKS, 5, 20);
        registerFlammable(BOPBlocks.JACARANDA_SLAB, 5, 20);
        registerFlammable(BOPBlocks.JACARANDA_STAIRS, 5, 20);
        registerFlammable(BOPBlocks.JACARANDA_FENCE, 5, 20);
        registerFlammable(BOPBlocks.JACARANDA_FENCE_GATE, 5, 20);
        registerFlammable(BOPBlocks.JACARANDA_SHELF, 30, 20);
        registerFlammable(BOPBlocks.PALM_LEAVES, 30, 60);
        registerFlammable(BOPBlocks.PALM_LOG, 5, 5);
        registerFlammable(BOPBlocks.PALM_WOOD, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_PALM_LOG, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_PALM_WOOD, 5, 5);
        registerFlammable(BOPBlocks.PALM_PLANKS, 5, 20);
        registerFlammable(BOPBlocks.PALM_SLAB, 5, 20);
        registerFlammable(BOPBlocks.PALM_STAIRS, 5, 20);
        registerFlammable(BOPBlocks.PALM_FENCE, 5, 20);
        registerFlammable(BOPBlocks.PALM_FENCE_GATE, 5, 20);
        registerFlammable(BOPBlocks.PALM_SHELF, 30, 20);
        registerFlammable(BOPBlocks.WILLOW_LEAVES, 30, 60);
        registerFlammable(BOPBlocks.WILLOW_LOG, 5, 5);
        registerFlammable(BOPBlocks.WILLOW_WOOD, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_WILLOW_LOG, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_WILLOW_WOOD, 5, 5);
        registerFlammable(BOPBlocks.WILLOW_PLANKS, 5, 20);
        registerFlammable(BOPBlocks.WILLOW_SLAB, 5, 20);
        registerFlammable(BOPBlocks.WILLOW_STAIRS, 5, 20);
        registerFlammable(BOPBlocks.WILLOW_FENCE, 5, 20);
        registerFlammable(BOPBlocks.WILLOW_FENCE_GATE, 5, 20);
        registerFlammable(BOPBlocks.WILLOW_SHELF, 30, 20);
        registerFlammable(BOPBlocks.DEAD_LEAVES, 30, 60);
        registerFlammable(BOPBlocks.DEAD_LOG, 5, 5);
        registerFlammable(BOPBlocks.DEAD_WOOD, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_DEAD_LOG, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_DEAD_WOOD, 5, 5);
        registerFlammable(BOPBlocks.DEAD_PLANKS, 5, 20);
        registerFlammable(BOPBlocks.DEAD_SLAB, 5, 20);
        registerFlammable(BOPBlocks.DEAD_STAIRS, 5, 20);
        registerFlammable(BOPBlocks.DEAD_FENCE, 5, 20);
        registerFlammable(BOPBlocks.DEAD_FENCE_GATE, 5, 20);
        registerFlammable(BOPBlocks.DEAD_SHELF, 30, 20);
        registerFlammable(BOPBlocks.MAGIC_LEAVES, 30, 60);
        registerFlammable(BOPBlocks.MAGIC_LOG, 5, 5);
        registerFlammable(BOPBlocks.MAGIC_WOOD, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_MAGIC_LOG, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_MAGIC_WOOD, 5, 5);
        registerFlammable(BOPBlocks.MAGIC_PLANKS, 5, 20);
        registerFlammable(BOPBlocks.MAGIC_SLAB, 5, 20);
        registerFlammable(BOPBlocks.MAGIC_STAIRS, 5, 20);
        registerFlammable(BOPBlocks.MAGIC_FENCE, 5, 20);
        registerFlammable(BOPBlocks.MAGIC_FENCE_GATE, 5, 20);
        registerFlammable(BOPBlocks.MAGIC_SHELF, 30, 20);
        registerFlammable(BOPBlocks.UMBRAN_LEAVES, 30, 60);
        registerFlammable(BOPBlocks.UMBRAN_LOG, 5, 5);
        registerFlammable(BOPBlocks.UMBRAN_WOOD, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_UMBRAN_LOG, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_UMBRAN_WOOD, 5, 5);
        registerFlammable(BOPBlocks.UMBRAN_PLANKS, 5, 20);
        registerFlammable(BOPBlocks.UMBRAN_SLAB, 5, 20);
        registerFlammable(BOPBlocks.UMBRAN_STAIRS, 5, 20);
        registerFlammable(BOPBlocks.UMBRAN_FENCE, 5, 20);
        registerFlammable(BOPBlocks.UMBRAN_FENCE_GATE, 5, 20);
        registerFlammable(BOPBlocks.UMBRAN_SHELF, 30, 20);
        registerFlammable(BOPBlocks.EMPYREAL_LEAVES, 30, 60);
        registerFlammable(BOPBlocks.EMPYREAL_LOG, 5, 5);
        registerFlammable(BOPBlocks.EMPYREAL_WOOD, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_EMPYREAL_LOG, 5, 5);
        registerFlammable(BOPBlocks.STRIPPED_EMPYREAL_WOOD, 5, 5);
        registerFlammable(BOPBlocks.EMPYREAL_PLANKS, 5, 20);
        registerFlammable(BOPBlocks.EMPYREAL_SLAB, 5, 20);
        registerFlammable(BOPBlocks.EMPYREAL_STAIRS, 5, 20);
        registerFlammable(BOPBlocks.EMPYREAL_FENCE, 5, 20);
        registerFlammable(BOPBlocks.EMPYREAL_FENCE_GATE, 5, 20);
        registerFlammable(BOPBlocks.EMPYREAL_SHELF, 30, 20);
        registerFlammable(BOPBlocks.ORIGIN_DANDELION, 60, 100);
        registerFlammable(BOPBlocks.ORIGIN_ROSE, 60, 100);
        registerFlammable(BOPBlocks.MARIGOLD, 60, 100);
        registerFlammable(BOPBlocks.VIOLET, 60, 100);
        registerFlammable(BOPBlocks.LAVENDER, 60, 100);
        registerFlammable(BOPBlocks.WHITE_LAVENDER, 60, 100);
        registerFlammable(BOPBlocks.PURPLE_WILDFLOWERS, 60, 100);
        registerFlammable(BOPBlocks.PINK_DAFFODIL, 60, 100);
        registerFlammable(BOPBlocks.PINK_HIBISCUS, 60, 100);
        registerFlammable(BOPBlocks.WHITE_PETALS, 60, 100);
        registerFlammable(BOPBlocks.GLOWFLOWER, 60, 100);
        registerFlammable(BOPBlocks.WILTED_LILY, 60, 100);
        registerFlammable(BOPBlocks.TALL_LAVENDER, 60, 100);
        registerFlammable(BOPBlocks.TALL_WHITE_LAVENDER, 60, 100);
        registerFlammable(BOPBlocks.BLUE_HYDRANGEA, 60, 100);
        registerFlammable(BOPBlocks.GOLDENROD, 60, 100);
        registerFlammable(BOPBlocks.ICY_IRIS, 60, 100);
        registerFlammable(BOPBlocks.WILLOW_VINE, 15, 100);
        registerFlammable(BOPBlocks.SPANISH_MOSS, 60, 100);
        registerFlammable(BOPBlocks.SPANISH_MOSS_PLANT, 60, 100);
        registerFlammable(BOPBlocks.GLOWWORM_SILK, 60, 100);
        registerFlammable(BOPBlocks.GLOWWORM_SILK_STRAND, 60, 100);
        registerFlammable(BOPBlocks.HANGING_COBWEB, 60, 100);
        registerFlammable(BOPBlocks.HANGING_COBWEB_STRAND, 60, 100);
        registerFlammable(BOPBlocks.STRINGY_COBWEB, 60, 100);
        registerFlammable(BOPBlocks.WEBBING, 60, 100);
        registerFlammable(BOPBlocks.SPROUT, 60, 100);
        registerFlammable(BOPBlocks.HIGH_GRASS, 60, 100);
        registerFlammable(BOPBlocks.HIGH_GRASS_PLANT, 60, 100);
        registerFlammable(BOPBlocks.CLOVER, 60, 100);
        registerFlammable(BOPBlocks.HUGE_CLOVER_PETAL, 60, 100);
        registerFlammable(BOPBlocks.MAPLE_LEAF_LITTER, 60, 100);
        registerFlammable(BOPBlocks.DUNE_GRASS, 60, 100);
        registerFlammable(BOPBlocks.DESERT_GRASS, 60, 100);
        registerFlammable(BOPBlocks.DEAD_GRASS, 60, 100);
        registerFlammable(BOPBlocks.TUNDRA_SHRUB, 60, 100);
        registerFlammable(BOPBlocks.ENDERPHYTE, 60, 100);
        registerFlammable(BOPBlocks.LUMALOOP, 60, 100);
        registerFlammable(BOPBlocks.LUMALOOP_PLANT, 60, 100);
        registerFlammable(BOPBlocks.DEAD_BRANCH, 60, 100);
        registerFlammable(BOPBlocks.BARLEY, 60, 100);

        // Strippable Blocks
        registerStrippable(BOPBlocks.ORIGIN_OAK_LOG, BOPBlocks.STRIPPED_ORIGIN_OAK_LOG);
        registerStrippable(BOPBlocks.ORIGIN_OAK_WOOD, BOPBlocks.STRIPPED_ORIGIN_OAK_WOOD);
        registerStrippable(BOPBlocks.FIR_LOG, BOPBlocks.STRIPPED_FIR_LOG);
        registerStrippable(BOPBlocks.FIR_WOOD, BOPBlocks.STRIPPED_FIR_WOOD);
        registerStrippable(BOPBlocks.PINE_LOG, BOPBlocks.STRIPPED_PINE_LOG);
        registerStrippable(BOPBlocks.PINE_WOOD, BOPBlocks.STRIPPED_PINE_WOOD);
        registerStrippable(BOPBlocks.MAPLE_LOG, BOPBlocks.STRIPPED_MAPLE_LOG);
        registerStrippable(BOPBlocks.MAPLE_WOOD, BOPBlocks.STRIPPED_MAPLE_WOOD);
        registerStrippable(BOPBlocks.REDWOOD_LOG, BOPBlocks.STRIPPED_REDWOOD_LOG);
        registerStrippable(BOPBlocks.REDWOOD_WOOD, BOPBlocks.STRIPPED_REDWOOD_WOOD);
        registerStrippable(BOPBlocks.MAHOGANY_LOG, BOPBlocks.STRIPPED_MAHOGANY_LOG);
        registerStrippable(BOPBlocks.MAHOGANY_WOOD, BOPBlocks.STRIPPED_MAHOGANY_WOOD);
        registerStrippable(BOPBlocks.JACARANDA_LOG, BOPBlocks.STRIPPED_JACARANDA_LOG);
        registerStrippable(BOPBlocks.JACARANDA_WOOD, BOPBlocks.STRIPPED_JACARANDA_WOOD);
        registerStrippable(BOPBlocks.PALM_LOG, BOPBlocks.STRIPPED_PALM_LOG);
        registerStrippable(BOPBlocks.PALM_WOOD, BOPBlocks.STRIPPED_PALM_WOOD);
        registerStrippable(BOPBlocks.WILLOW_LOG, BOPBlocks.STRIPPED_WILLOW_LOG);
        registerStrippable(BOPBlocks.WILLOW_WOOD, BOPBlocks.STRIPPED_WILLOW_WOOD);
        registerStrippable(BOPBlocks.DEAD_LOG, BOPBlocks.STRIPPED_DEAD_LOG);
        registerStrippable(BOPBlocks.DEAD_WOOD, BOPBlocks.STRIPPED_DEAD_WOOD);
        registerStrippable(BOPBlocks.MAGIC_LOG, BOPBlocks.STRIPPED_MAGIC_LOG);
        registerStrippable(BOPBlocks.MAGIC_WOOD, BOPBlocks.STRIPPED_MAGIC_WOOD);
        registerStrippable(BOPBlocks.UMBRAN_LOG, BOPBlocks.STRIPPED_UMBRAN_LOG);
        registerStrippable(BOPBlocks.UMBRAN_WOOD, BOPBlocks.STRIPPED_UMBRAN_WOOD);
        registerStrippable(BOPBlocks.HELLBARK_LOG, BOPBlocks.STRIPPED_HELLBARK_LOG);
        registerStrippable(BOPBlocks.HELLBARK_WOOD, BOPBlocks.STRIPPED_HELLBARK_WOOD);
        registerStrippable(BOPBlocks.EMPYREAL_LOG, BOPBlocks.STRIPPED_EMPYREAL_LOG);
        registerStrippable(BOPBlocks.EMPYREAL_WOOD, BOPBlocks.STRIPPED_EMPYREAL_WOOD);

        //Compostable Blocks
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM_HIGH, BOPBlocks.GLOWSHROOM_BLOCK);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM_HIGH, BOPBlocks.TOADSTOOL_BLOCK);
        //registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM_HIGH, BOPBlocks.VOIDCAP_BLOCK);

        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.WHITE_FLOWER_PETAL_BLOCK);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.LIGHT_GRAY_FLOWER_PETAL_BLOCK);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.GRAY_FLOWER_PETAL_BLOCK);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.BLACK_FLOWER_PETAL_BLOCK);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.BROWN_FLOWER_PETAL_BLOCK);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.RED_FLOWER_PETAL_BLOCK);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.ORANGE_FLOWER_PETAL_BLOCK);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.YELLOW_FLOWER_PETAL_BLOCK);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.LIME_FLOWER_PETAL_BLOCK);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.GREEN_FLOWER_PETAL_BLOCK);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.CYAN_FLOWER_PETAL_BLOCK);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.LIGHT_BLUE_FLOWER_PETAL_BLOCK);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.BLUE_FLOWER_PETAL_BLOCK);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.PURPLE_FLOWER_PETAL_BLOCK);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.MAGENTA_FLOWER_PETAL_BLOCK);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.PINK_FLOWER_PETAL_BLOCK);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.FLOWER_STEM);

        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.FLOWERING_OAK_SAPLING);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.FLOWERING_OAK_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.CYPRESS_SAPLING);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.CYPRESS_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.SNOWBLOSSOM_SAPLING);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.SNOWBLOSSOM_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.ORIGIN_OAK_SAPLING);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.ORIGIN_OAK_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.FIR_SAPLING);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.FIR_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.PINE_SAPLING);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.PINE_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.MAPLE_SAPLING);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.PINK_MAPLE_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.MAGENTA_MAPLE_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.PURPLE_MAPLE_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.REDWOOD_SAPLING);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.REDWOOD_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.MAHOGANY_SAPLING);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.MAHOGANY_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.JACARANDA_SAPLING);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.JACARANDA_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.PALM_SAPLING);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.PALM_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.WILLOW_SAPLING);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.WILLOW_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.DEAD_SAPLING);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.DEAD_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.MAGIC_SAPLING);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.MAGIC_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.UMBRAN_SAPLING);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.UMBRAN_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.HELLBARK_SAPLING);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.HELLBARK_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.EMPYREAL_SAPLING);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.EMPYREAL_LEAVES);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.GLOWING_MOSS_CARPET);

        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.FLOWER_BUD);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.ORIGIN_DANDELION);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.ORIGIN_ROSE);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.MARIGOLD);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.VIOLET);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.LAVENDER);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.WHITE_LAVENDER);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.PURPLE_WILDFLOWERS);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.ORANGE_COSMOS);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.PINK_DAFFODIL);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.PINK_HIBISCUS);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.WATERLILY);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.WHITE_PETALS);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.GLOWFLOWER);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.WILTED_LILY);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.BURNING_BLOSSOM);

        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.TALL_LAVENDER);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.TALL_WHITE_LAVENDER);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.BLUE_HYDRANGEA);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.GOLDENROD);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.ICY_IRIS);

        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.WILLOW_VINE);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.SPANISH_MOSS);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.SPANISH_MOSS_PLANT);

        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.SPROUT);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.HIGH_GRASS);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.HIGH_GRASS_PLANT);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.CLOVER);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.HUGE_CLOVER_PETAL);

        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.MAPLE_LEAF_LITTER);

        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.DUNE_GRASS);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.DESERT_GRASS);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.DEAD_GRASS);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.TUNDRA_SHRUB);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.CATTAIL);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.BARLEY);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.REED);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.WATERGRASS);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW_MEDIUM, BOPBlocks.TINY_CACTUS);

        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.DEAD_BRANCH);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.BRAMBLE);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.BRAMBLE_LEAVES);

        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.ENDBLOOM);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.ENDERPHYTE);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.LUMALOOP);
        registerCompostable(ContextIntProviders.COMPOSTABLE_LOW, BOPBlocks.LUMALOOP_PLANT);

        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.TOADSTOOL);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.GLOWSHROOM);
        //registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.VOIDCAP);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.GLOWING_MOSS_BLOCK);
        registerCompostable(ContextIntProviders.COMPOSTABLE_MEDIUM, BOPBlocks.HUGE_LILY_PAD);

    }

    private static void registerCompostable(ResourceKey<ContextIntProvider> chance, ItemLike item)
    {
        BlockHelper.registerCompostable(chance, item);
    }
}
