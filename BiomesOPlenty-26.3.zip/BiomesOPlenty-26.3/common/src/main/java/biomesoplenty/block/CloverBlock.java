/*******************************************************************************
 * Copyright 2022, the Glitchfiend Team.
 * All rights reserved.
 ******************************************************************************/
package biomesoplenty.block;

import biomesoplenty.worldgen.feature.BOPVegetationFeatures;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.FlowerBedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.block.BonemealSource;

public class CloverBlock extends FlowerBedBlock
{
    public CloverBlock(Properties properties)
    {
        super(properties, 3);
    }

    @Override
    public boolean isBonemealSuccess(Level worldIn, RandomSource rand, BlockPos pos, BlockState state, BonemealSource source)
    {
        return (double)rand.nextFloat() < 0.4D;
    }

    @Override
    public void performBonemeal(ServerLevel level, RandomSource rand, BlockPos pos, BlockState state, BonemealSource source)
    {
        int i = state.getValue(AMOUNT);
        if (i < 4)
        {
            level.setBlock(pos, state.setValue(AMOUNT, Integer.valueOf(i + 1)), 2);
        }
        else
        {
            this.growHugeClover(level, rand, pos, state);
            //popResource(level, pos, new ItemStack(this));
        }
    }

    public boolean growHugeClover(ServerLevel level, RandomSource rand, BlockPos pos, BlockState state)
    {
        level.removeBlock(pos, false);
        Registry<Feature> configuredFeatureRegistry = level.registryAccess().lookupOrThrow(Registries.FEATURE);
        Feature configuredfeature = configuredFeatureRegistry.get(BOPVegetationFeatures.HUGE_CLOVER).orElseThrow().value();

        if (configuredfeature.place(level, level.getChunkSource().getGenerator(), rand, pos))
        {
            return true;
        }
        else
        {
            level.setBlock(pos, state, 3);
            return false;
        }
    }
}
