/*******************************************************************************
 * Copyright 2022, the Glitchfiend Team.
 * All rights reserved.
 ******************************************************************************/
package biomesoplenty.block;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.FlowerBedBlock;
import net.minecraft.world.level.block.state.BlockState;

public class PurpleWildflowerBlock extends FlowerBedBlock
{
    public PurpleWildflowerBlock(Properties properties)
    {
        super(properties, 3);
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader worldIn, BlockPos pos)
    {
        BlockState ground = worldIn.getBlockState(pos.below());

        return ground.is(BlockTags.SAND) || super.canSurvive(state, worldIn, pos);
    }
}
