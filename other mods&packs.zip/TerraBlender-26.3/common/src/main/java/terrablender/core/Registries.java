/**
 * Copyright (C) Glitchfiend
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package terrablender.core;

import net.minecraft.core.Registry;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import terrablender.api.data.RegionDefinition;
import terrablender.api.data.condition.BiomeMappingConditionType;

public class Registries {
    public static final ResourceKey<Registry<RegionDefinition>> REGION = ResourceKey.createRegistryKey(Identifier.fromNamespaceAndPath(TerraBlender.MOD_ID, "region"));

    public static final ResourceKey<Registry<BiomeMappingConditionType<?>>> BIOME_MAPPING_CONDITION = ResourceKey.createRegistryKey(Identifier.fromNamespaceAndPath(TerraBlender.MOD_ID, "biome_mapping_condition"));
}
