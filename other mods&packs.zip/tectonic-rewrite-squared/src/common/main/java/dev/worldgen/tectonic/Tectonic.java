package dev.worldgen.tectonic;

import com.mojang.serialization.MapCodec;
import dev.worldgen.apollib.config.ApollibConfigHolder;
import dev.worldgen.tectonic.config.ConfigState;
import dev.worldgen.tectonic.worldgen.placementmodifier.HeightStabilizedCount;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.levelgen.DensityFunction;
import net.minecraft.world.level.levelgen.placement.PlacementModifierType;
import net.msrandom.multiplatform.annotations.Expect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.BiConsumer;

public class Tectonic {
    public static final String MOD_ID = "tectonic";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    /**
     * Value saved in chunks used for blending between Tectonic versions.
     * <ol>
     *     <li>3.0.0 - 3.0.8, 3.0.10+</li>
     *     <li>3.0.9</li>
     * </ol>
     */
    public static int BLENDING_VERSION = 1;
    public static String BLENDING_KEY = "tectonic:blending_version";
    
    public static final ApollibConfigHolder<ConfigState> CONFIG = new ApollibConfigHolder<>(
        Tectonic.id("tectonic"),
        ApollibConfigHolder.CONFIG_DIRECTORY.resolve("tectonic.json"),
        ConfigState.CODEC,
        ConfigState.DEFAULT_STATE
    );

    public static void init() {
        CONFIG.load();
    }

    public static Identifier idVanilla(String name) {
        return Identifier.withDefaultNamespace(name);
    }

    public static Identifier id(String name) {
        return Identifier.fromNamespaceAndPath(MOD_ID, name);
    }

    @Expect
    public static int getBlendingVersion(CompoundTag tag);

    @Expect
    public static boolean canRunCommand(CommandSourceStack stack);

    @Expect
    public static void registerDensityFunctionTypes(BiConsumer<String, MapCodec<? extends DensityFunction>> consumer);
    
    public static void registerPlacementModifierTypes(BiConsumer<String, PlacementModifierType<?>> consumer) {
        consumer.accept("height_stabilized_count", HeightStabilizedCount.TYPE);
    }

    public static boolean isEnabled() {
        return Tectonic.CONFIG.getState().general.modEnabled;
    }
}
